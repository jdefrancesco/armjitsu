#==================================CONSTANTS================================================

#--------------DEFAULTS----------------------
DEFAULT_MAX_INT_VALUE = 1000
DEFAULT_MIN_INT_VALUE = 0
DEFAULT_FUZZ_ELEMENT_ISFUZZABLE = True
#--------------END DEFAULTS------------------


CONTROL_CHANNEL_MESSAGE_NAMES_LIST = ["UL-DCCH-Message","DL-CCCH-Message","UL-CCCH-Message",
                                       "DL-DCCH-Message"]


XER_TREE_ROOT_NODE_NAME = "UL-DCCH-Message"
XER_MESSAGE_NODE_NAME = "message"

XSD_SIMPLE_TYPE_UNION = "union"

XSD_EXT = ".xsd"

XML_EXT = ".xml"

HEX_EXT = ".hex"

FUZZ_ELEMENT_NODE_TYPE_ATTRIB = "type"
FUZZ_ELEMENT_NODE_NAME_ATTRIB = "name"
FUZZ_ELEMENT_NODE_VALUE_ATTRIB = "value"
FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB = "minLength"
FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB = "maxLength"
FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB = "maxValue"
FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB = "minValue"
FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB = "defaultValue"
FUZZ_ELEMENT_NODE_IS_OPTIONAL = "isOptional"
FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB = "isFuzzable"

FUZZ_TREE_ROOT_MESSAGE_TYPE_ATTRIB =  "messsageType"



MESSAGE_TEMPLATE_SUFFIX = "Template"


FUZZ_ELEMENT_TYPE_SEQUENCE = "sequence"
FUZZ_ELEMENT_TYPE_CHOICE = "choice"
FUZZ_ELEMENT_TYPE_UNION = XSD_SIMPLE_TYPE_UNION
FUZZ_ELEMENT_TYPE_UNKNOWN = "unknown"
FUZZ_ELEMENT_TYPE_GROUP = "group"
FUZZ_ELEMENT_TYPE_NULL =  "Null"

FUZZ_ELEMENT_NODE_TAG = "fuzz_element"

FUZZ_ELEMENT_UNKNOWN_NAME = "Unknown_Name"

FUZZ_TREE_NODE_TAG = "fuzz_tree"

FUZZ_ELEMENT_NODE_NAME = "fuzz_element"
FUZZ_ENUMERATED_VALUE_NODE_NAME = "enumerated_value"

FUZZ_ENUMERATED_VALUE_TYPE = FUZZ_ENUMERATED_VALUE_NODE_NAME




XSD_TAG = "{http://www.w3.org/2001/XMLSchema}"
XSD_ELEMENT_TAG = XSD_TAG + "element"
XSD_COMPLEX_TYPE_TAG = XSD_TAG +"complexType"
XSD_SIMPLE_TYPE_TAG = XSD_TAG +"simpleType"
XSD_RESTRICTION_TAG = XSD_TAG +"restriction"
XSD_ENUMERATION_TAG = XSD_TAG +"enumeration"
XSD_MIN_LENGTH_TAG = XSD_TAG  +"minLength"
XSD_MAX_LENGTH_TAG = XSD_TAG  +"maxLength"
XSD_LENGTH_TAG = XSD_TAG  +"length"
XSD_CHOICE_TAG = XSD_TAG  +"choice"
XSD_SEEQUENCE_TAG = XSD_TAG  +"sequence"

XSD_MIN_INCLUSIVE_TAG = XSD_TAG + "minInclusive"
XSD_MAX_INCLUSIVE_TAG = XSD_TAG + "maxInclusive"

XSD_UNION_TAG = XSD_TAG + XSD_SIMPLE_TYPE_UNION



XSD_HEX_BINARY = "xsd:hexBinary"

XSD_UNSIGNED_BYTE = "xsd:unsignedByte"
XSD_BYTE ="xsd:byte"
XSD_TOKEN = "xsd:token"
XSD_UNSIGNED_SHORT = "xsd:unsignedShort"
XSD_UNSIGNED_INT = "xsd:unsignedInt"

ASN1_BITSTRING ="asn1:BitString"


MARBEN_INTEGER_TYPE = "INTEGER_Type"
MARBEN_BIT_STRING_TYPE = "BIT_STRING_Type"
MARBEN_ENUMERATED_TYPE = "ENUMERATED_Type"
MARBEN_OCTET_STRING_TYPE ="OCTET_STRING_Type"
MARBEN_BOOL_TYPE = "bool_Type"
MARBEN_NULL_TYPE = "NULL_Type"



PRIMITIVE_ASN_FUZZ_TYPE_ENUM = "Enumerated"
PRIMITIVE_ASN_FUZZ_TYPE_ENUM_VALUE = "enumerated_value"
PRIMITIVE_ASN_FUZZ_TYPE_INTEGER = "Integer"
PRIMITIVE_ASN_FUZZ_TYPE_BITSTRING = "BitString"
PRIMITIVE_ASN_FUZZ_TYPE_BOOLEAN = "boolean"
PRIMITIVE_ASN_FUZZ_TYPE_OCTETSTRING = "OctetString"
PRIMITIVE_ASN_FUZZ_TYPE_NULL = "Null"



XSD_COMPLEX_TYPE = "complexType"
XSD_SIMPLE_TYPE = "simpleType"



XSD_RESTRICTION_ATTRIB_BASE = "base"


XSD_ASN_PREFIX = "asn1"
XSD_PREFIX = "xsd"

XSD_NAME_ATTRIBUTE = "name"
XSD_TYPE_ATTRIBUTE = "type"
XSD_VALUE_ATTRIBUTE = "value"

XSD_ELEMENT_MIN_OCCUR_ATTRIBUTE = "minOccurs"
XSD_ELEMENT_MAX_OCCUR_ATTRIBUTE = "maxOccurs"

FUZZ_TREE_ROOT_TAG = "fuzz_tree"
FUZZ_ELEMENT_NODE_NAME = "fuzz_element"
FUZZ_ENUMERATED_VALUE = "enumerated_value"


XSD_TREE_LIST = []




BOOL_TRUE_STRING = "true"
BOOL_FALSE_STRING = "false"



PRIMITIVE_TYPE_LIST = [PRIMITIVE_ASN_FUZZ_TYPE_BOOLEAN,
                       PRIMITIVE_ASN_FUZZ_TYPE_ENUM,
                       PRIMITIVE_ASN_FUZZ_TYPE_INTEGER,
                       PRIMITIVE_ASN_FUZZ_TYPE_BITSTRING,
                       PRIMITIVE_ASN_FUZZ_TYPE_OCTETSTRING,
                       PRIMITIVE_ASN_FUZZ_TYPE_NULL] 



#==================================END CONSTANTS============================================
