import xml.etree.ElementTree as ET
from constants import *

class FuzzElementPrimitive:
        
               
    def __init__(self, primitive_fuzz_node = None) :
        
        #Default initialization
        self.name = None
        self.type = None
        self.value = None
        self.minLength = None
        self.maxLength = None
        self.minValue  = None
        self.maxValue  = None
        self.defaultValue = None
        self.children = []
        self.isFuzzable = DEFAULT_FUZZ_ELEMENT_ISFUZZABLE
        
                
        if primitive_fuzz_node != None:
        
            #Get the name of the primtive node
            if FUZZ_ELEMENT_NODE_NAME_ATTRIB in  primitive_fuzz_node.attrib.keys() :
                self.name = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
                
            else :
                self.name = None
            
                 
            #Get and set the type             
            self.type = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_TYPE_ATTRIB]
       
            # Get and set the attributes of primitive node
            if FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB in primitive_fuzz_node.attrib.keys() :
                self.minLength = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB]
            
            if FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB in primitive_fuzz_node.attrib.keys() :
                self.maxLength = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB]
            
            if FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
                self.maxValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB]
                
            if FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
                self.minValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB]    
                
            if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
                self.defaultValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]
                
            if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in  primitive_fuzz_node.attrib.keys() :
                if primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB].lower() == BOOL_TRUE_STRING :
                    self.isFuzzable = True
                else:
                    self.isFuzzable = False
                
                
             #Create child nodes for ENUM fuzz element
            if self.type == PRIMITIVE_ASN_FUZZ_TYPE_ENUM:
                for child in primitive_fuzz_node.findall(FUZZ_ENUMERATED_VALUE_TYPE) :
                    fuzz_child_primitive = FuzzElementPrimitive() 
                    fuzz_child_primitive.type = FUZZ_ENUMERATED_VALUE_TYPE
                    fuzz_child_primitive.value = child.attrib[XSD_VALUE_ATTRIBUTE]
                    self.children.append(fuzz_child_primitive)
                    
    


    def prettyprint(self) :
        print "\n========Fuzz Element Primitive Struct========"
        print "Name: '{}'".format(self.name) 
        print "Type: '{}'".format(self.type)
        print "Min value: '{}'".format(str(self.minValue))
        print "Max value: '{}'".format(str(self.maxValue))     
        print "========END Fuzz Element Primitive Struct======\n"
        
    def createFuzzTree(self, fuzz_primitive_tree_root = None) :        
        
        if(fuzz_primitive_tree_root == None):  
            print "ERROR...Fuzz primitive tree root is null"
            return None
            
        new_fuzz_primitive_node = None
            
        if self.type == FUZZ_ENUMERATED_VALUE_TYPE :
            new_fuzz_primitive_node  = ET.SubElement(fuzz_primitive_tree_root,FUZZ_ENUMERATED_VALUE_NODE_NAME)
            new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_VALUE_ATTRIB, self.value)
            
        else :                
            #Create xer node and append to root       
            new_fuzz_primitive_node  = ET.SubElement(fuzz_primitive_tree_root,FUZZ_ELEMENT_NODE_NAME)            
            new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_TYPE_ATTRIB, self.type)
            new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_NAME_ATTRIB, self.name)
            
            if self.minLength != None :
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB, self.minLength)
           
            if self.maxLength != None :
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB, self.maxLength)    
                        
            if self.minValue != None :
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB, self.minValue)
                
            if self.maxValue != None :
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB, self.maxValue)
                
            if self.defaultValue != None :
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB, self.defaultValue)
           
            if self.isFuzzable != None :                           
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB, str(self.isFuzzable))
           
            #Create enum value children
            if self.type == PRIMITIVE_ASN_FUZZ_TYPE_ENUM:
                for child in self.children :
                    child.createFuzzTree(new_fuzz_primitive_node)
                    
                
        
        return fuzz_primitive_tree_root