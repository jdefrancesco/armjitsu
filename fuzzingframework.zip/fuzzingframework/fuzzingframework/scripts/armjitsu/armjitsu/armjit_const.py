"""
armjit_const.py holds general constants that may be used in all python files within the project.
"""

LOGGER_NAME = "armjitsu_logger"
