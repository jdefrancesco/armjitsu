import getpass
from constants import *




#==================================CONSTANTS================================================
USER_NAME = getpass.getuser()
ASN_MESSAGE_FILE_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/asn/25331_c30.asn".format(USER_NAME)
ASN_KEYWORD_CONTAINING = "CONTAINING"

#==================================END CONSTANTS============================================



#--------------------------------CLASS DEFINITIONS---------------------------------
class ASNVariableWithContaining :
    def __init__(self):
        self.primitiveType = None
        self.messageType = None
        
#--------------------------------END CLASS DEFINITIONS---------------------------------        



#--------------------------------GLOBAL VARIABLE DEFINITIONS---------------------------------

ASN_VAR_NAME_CONTAINING_LOOKUP_DIC = dict()
        
#--------------------------------END GLOBAL VARIABLE DEFINITIONS---------------------------------  

'''
    Description: Returns a Dictionary that has ASN variable names that have a 'Containing' keyword
                 associated with it and also provides the type (e.g. Bitstring and OctetString)

'''
def getASNVarNamesWithContainingLookupTable() :
    pass

def buildASNVarNamesWithContainingLookupTable() :
    print "Building 'ASNVARNameesWithContaing' Lookup Table"
    f = open(ASN_MESSAGE_FILE_PATH,'r')
    
    asnDefinitionLines = f.readlines()
        
    
    for i in range(len(asnDefinitionLines)) :
    
        asnDefinitionLine = asnDefinitionLines[i]
        
        if i > 0 : 
            prevDefinitionLine = asnDefinitionLines[i-1]
        
        #Only consider lines that have the keyword 'CONTAINING
        if ASN_KEYWORD_CONTAINING not in asnDefinitionLine:        
            continue
            
        
        asn_var_name = None
        primitive_type = None
        
        
        #PREVIOUS    
        prev_def_array = prevDefinitionLine.strip().split("\t")        
        #Remove empty string from list
        prev_def_array = filter(None, prev_def_array)        
        #print "def array -->{}".format(repr(prev_def_array))
        
        #CURRENT
        curr_def_array = asnDefinitionLine.strip().split("\t")        
        #Remove empty string from list
        curr_def_array = filter(None, curr_def_array)        
        #print "curr def array -->{}".format(repr(curr_def_array))

        
        #Check if the 'CONTAINING' keyword on the same line as variable
        if curr_def_array[0].startswith("("+ASN_KEYWORD_CONTAINING) :
            print "Variable NOT on same line"
            asn_var_name = prev_def_array[0]
            primitive_type = prev_def_array[1]
        else: 
            print "Variable on same line"
            asn_var_name = curr_def_array[0]
            primitive_type = curr_def_array[1].split("(")[0]
        
        print "Variable name: {}  Primitive Type:{} ".format(asn_var_name,primitive_type)
        #print "Keyword 'Containing' Line -->{}".format(asnDefinitionLine)
        #print "Previous line -->{}".format(prevDefinitionLine)
        
        print "\n"
        
        
        


def testHarness():
    print "====================BEGIN TEST======================\n"
        
    buildASNVarNamesWithContainingLookupTable()
    
    
    print "\n==================== END TEST======================="

def main():
    print "\n*********ASN Parser (version 1)*********\n"
    
       
    testHarness()

  


if __name__ == "__main__" :    
    main()
