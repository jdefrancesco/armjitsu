import sys, os
from antiparser import *

#current_path = os.path.dirname(os.path.realpath(__file__))

#print "Current path is {}".format(current_path)

# the mock-0.3.1 dir contains testcase.py, testutils.py & mock.py
#sys.path.append('/home/chibimon/Projects/fuzzer/antiparser-2.0')





def generateASNBoolean() :
    from random import randint
    rand_value = randint(0,1)
    
    rand_boolean = "foobar"

    #print "Random value is {}".format(str(rand_value))
    if rand_value == 1 :
        rand_boolean = "true"
    else :
        rand_boolean = "false"
          
    return rand_boolean


def getValidBitStringLength(bit_str_length) :
    #Make length of bit string  a multiple of 4
    
    cur_value = bit_str_length 
    while cur_value%4 != 0 :
        #print "incrementing by one from '{}' to '{}' ".format(cur_value, cur_value+1)
        cur_value = cur_value + 1
      
    valid_length = cur_value  
    #print "Valid length for string of length '{}' is '{}'".format(bit_str_length,valid_length)

    return valid_length
     

     
def generateASNEnumerated(enum_list) :
    from random import randint
    
    enum_length = len(enum_list)    
    rand_enum_index = randint(0,enum_length-1)
    
    rand_enum = enum_list[rand_enum_index]
    
    return rand_enum
    
     

def generateASNInteger(min_size=0, max_size=100):
    from random import randint
    rand_value_str = str(randint(min_size,max_size))
    return rand_value_str
     

def generateASNBitString(min_size=1, max_size=50):
    from random import randint
    rand_length = randint(min_size,max_size)
    
    bit_string = ""
    
    #print "Random string length is {} with min :{} max:{}".format(rand_value,min_size,max_size)
    for i in range(rand_length) :
        bit_string = bit_string + str(randint(0,1))
    
    return bit_string 

def generateASNOctetString(min_size=0, max_size=20):
    ap = antiparser()


    newstring = apString()

    newstring.setMinSize(min_size)
    newstring.setMaxSize(max_size)

    ap.append(newstring)
    ap.permute()

    payload =ap.getPayload()

    #convert charaters  in string to hex digits
    gen_octet_string = " ".join("{:02x}".format(ord(c)) for c in payload)
    
    return gen_octet_string


def testHarness():
    print "\n+++++++++++++++Running test harness++++++++++++++++++"

    print "\n***Testing method 'generateASNBoolean'***"
    gen_boolean = generateASNBoolean()
    print "boolean generated is '{}'\n".format(gen_boolean)

    print "\n***Testing method 'generateASNInteger'***"
    gen_integer = generateASNInteger()
    print "integer generated is '{}'\n".format(gen_integer)

    print "\n***Testing method 'generateASNOctetString'***"
    gen_octet_string = generateASNOctetString()
    print "octet string generated is '{}'\n".format(gen_octet_string)

    print "\n***Testing method 'generateASNBitString'***"
    gen_bit_string = generateASNBitString()
    print "Generated Bit string :{}'\n".format(gen_bit_string)

    print "+++++++++++++++END test harness++++++++++++++++++\n"

if __name__ == "__main__" :    
    testHarness()



#ap = antiparser()

#newstring = apCString()

#newstring.setMinSize(10)
#newstring.setMaxSize(10)

#ap.append(newstring)

#ap.permute()

#ap.display()

#payload =ap.getPayload()

#print "Payload is " + str(payload)
