'''
 Description: Fuzzes primitive elements of a asn message template, which contains 
              'fuzz_element' nodes with appropriate attributes to indicate the valid ranges
              and other pertinent information                            
''' 

import sys, os
import xml.etree.ElementTree as ET

from asnPrimitiveGenerator import *

XSD_CLASS_DEFINITIONS_PATH = "C:/Users/mjones30/Documents/WPG/Roosevelt_IRAD/fuzzing/25.331_xsd/Class-definitions.xsd"

PDU_TYPE = "UL-DCCH"
MESSAGE_TYPE = "RRCConnectionSetupComplete"



class FuzzElement:
    def __init__(self) :
        self.name = []
        self.type = []
        self.min_size = []
        self.max_size = []
        self.children = []
        
class FuzzElementChild:
    def __init__(self) :
        self.name = []
        self.asnDefType = []
      

        
def getUL_DCCH_Definition_Node(xsd_class_definition_path): 
    tree = ET.parse(xsd_class_definition_path)
    root = tree.getroot()
    
    
    for child in root:
        if child.attrib and "name" in child.attrib:
            #print child.tag, child.attrib
            if child.attrib["name"] == PDU_TYPE+ "-Message":
                print child.tag, child.attrib
                return child
    return
    

def getFuzzElementChildren(node):    
    print "Getting children"
    
    
    fuzz_element_child_list = []
    
    for child in node.iter('{http://www.w3.org/2001/XMLSchema}element') :
        #print "Fuzz Child-->" + child.tag, child.attrib
        fuzz_element_child = FuzzElementChild()
        fuzz_element_child.name = child.attrib['name']
        fuzz_element_child.asnDefType = child.attrib['type']
        fuzz_element_child_attrs = vars(fuzz_element_child)  
        print "Fuzz_element_child-> "+', '.join("%s: %s" % item for item in fuzz_element_child_attrs.items()) 
        fuzz_element_child_list.append(fuzz_element_child)
        
    
    return fuzz_element_child_list    

  
def getFuzzElementType(node) : 
    for child in node:
        if "sequence" in child.tag :
            return "sequence"
            
        if "choice" in child.tag :
            return "choice"
            
def getFuzzElementMinSize(node) :
    
    if not "minOccurs" in node.attrib :
        #By default minOccurs=1
        return 1
    else :
        return int(node.attrib["minOccurs"])
        
def getFuzzElementMaxSize(node) :
    
    if not "maxOccurs" in node.attrib :
        #By default minOccurs=1
        return 1
    else :
        return int(node.attrib["maxOccurs"])        
           
        
def getFuzzElementInformation(node) :
    fuzz_element = FuzzElement()
    fuzz_element.name = node.attrib["name"]
    fuzz_element_attrs = vars(fuzz_element)  

    fuzz_element.type = getFuzzElementType(node)
    
    fuzz_element.min_size = getFuzzElementMinSize(node)
    fuzz_element.max_size = getFuzzElementMaxSize(node)
    
    fuzz_element.children=getFuzzElementChildren(node)
    
    print "Fuzz_element-> "+', '.join("%s: %s" % item for item in fuzz_element_attrs.items())

def main() :
    print "\n++++++++++++++++ASN XSD Parser++++++++++++++++\n"
    
    ul_dcch_node = getUL_DCCH_Definition_Node(XSD_CLASS_DEFINITIONS_PATH)
    
    getFuzzElementInformation(ul_dcch_node)
        
    
    
    



    

if __name__ == "__main__" :    
    main()



