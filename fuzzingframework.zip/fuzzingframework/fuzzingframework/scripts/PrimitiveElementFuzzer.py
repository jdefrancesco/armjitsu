################################################################################
################################################################################
#
# FILE: PrimitiveElementFuzzer.py (version 4)
#
# DESCRIPTION: Stage 2 of construction of XER, which takes as input the output of
#              stage 1. Specifically, this stage fuzzes primitive elements of an
#              asn message template, which contains  'fuzz_element' nodes with 
#              appropriate attributes to indicate the valid ranges
#              and other pertinent information     
#
# LIMITATIONS: Python2.7
#
#
# AUTHOR: Malachi Jones (mjones30)
#
################################################################################

import sys, os
import xml.etree.ElementTree as ET
import getpass
from asnPrimitiveGenerator import *
from constants import *


#===========================CONFIGURABLE VALUES ===========================================
USER_NAME = getpass.getuser()
#DEFAULT_PRIMITIVE_FUZZ_ELEMENT_MESSAGE_IN_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/fuzzed/fuzzableMessage.xml".format(USER_NAME)
DEFAULT_PRIMITIVE_FUZZ_ELEMENT_MESSAGE_IN_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/fuzzed/exampleFuzzedMessage.xml".format(USER_NAME)
DEFAULT_XER_MESSAGE_OUT_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/fuzzed/completedlyFuzzedMessage.xml".format(USER_NAME)
#============================END CONFIGURABLE VALUES=======================================


#==================================CONSTANTS================================================
FUZZ_ELEMENT_ASN_NAME = FUZZ_ELEMENT_NODE_NAME_ATTRIB
FUZZ_ELEMENT_ASN_TYPE = FUZZ_ELEMENT_NODE_TYPE_ATTRIB
FUZZ_ELEMENT_ASN_OPTIONAL = FUZZ_ELEMENT_NODE_IS_OPTIONAL
#==================================END CONSTANTS============================================
   
##
# @brief Takes as input an xml message with primitive fuzz element markers and fuzzes  those elements to generate an XER
# @param  primitive_fuzz_element_message_in_path: primitive fuzz element message input  path
# @param  xer_message_out_path: xer message output path
# @return None   
def primitiveElementFuzzer(primitive_fuzz_element_message_in_path = None, xer_message_out_path = None ) :
    
    
    #Check if input message path specified. If not, use default
    if primitive_fuzz_element_message_in_path == None :
        print "Using default primitive fuzz element message input path '{}'".format(DEFAULT_PRIMITIVE_FUZZ_ELEMENT_MESSAGE_IN_PATH)
        primitive_fuzz_element_message_in_path =  DEFAULT_PRIMITIVE_FUZZ_ELEMENT_MESSAGE_IN_PATH
    
    
    #Check if output path for generated xer message is specified.  If not, use defaults
    if xer_message_out_path == None :
        print "Using default  xer message output path '{}'".format(DEFAULT_XER_MESSAGE_OUT_PATH)
        xer_message_out_path = DEFAULT_XER_MESSAGE_OUT_PATH
    
    #Parse the xml and get the root node
    tree = ET.parse(primitive_fuzz_element_message_in_path)
    root = tree.getroot()

    
    #Iterate through the fuzz elements and only fuzz the primitives
    for fuzz_element in root.iter(FUZZ_ELEMENT_NODE_NAME)  :            
        element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
        element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME] 
        
     
        if element_type  == PRIMITIVE_ASN_FUZZ_TYPE_INTEGER :
            fuzzASNInteger(fuzz_element)
            
        elif element_type == PRIMITIVE_ASN_FUZZ_TYPE_BITSTRING :
            fuzzASNBitString(fuzz_element)
            
        elif element_type == PRIMITIVE_ASN_FUZZ_TYPE_ENUM :
            fuzzASNEnumerated(fuzz_element)
            
        elif element_type == PRIMITIVE_ASN_FUZZ_TYPE_BOOLEAN :
            fuzzASNBoolean(fuzz_element)
            
        elif element_type == PRIMITIVE_ASN_FUZZ_TYPE_OCTETSTRING:
            fuzzASNOctetString(fuzz_element)
            
        elif element_type == PRIMITIVE_ASN_FUZZ_TYPE_NULL:
            fuzzASNNull(fuzz_element)
                     
        else : 
            print "WARNING: Unsupported primitive of type '{}'".format(element_type)
            fuzzTypeNotSupported(fuzz_element)
    
    #print "\n***Writing out fuzzed message to '{}'***".format(xer_message_out_path)
    tree.write(xer_message_out_path)



##
# @brief Returns 'true' if an element is a primitive type
# @param  element_type: type of element
# @return primitive ==> true , else: false
def isPrimitiveElement(element_type) :

    if element_type in PRIMITIVE_TYPE_LIST:
        #Element type is a primitive
        return True
    else:
        return False
        
   


##
# @brief Fuzzes an asn element of type boolean based on the attributes of the fuzz_element node
# @param  fuzz_element_boolean: type of element
def fuzzASNBoolean(fuzz_element_boolean):
    fuzz_element = fuzz_element_boolean
 
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
       
    
    #Make sure the fuzz element is of type enumerated
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_BOOLEAN :
        print "Error: Expecting to fuzz element of type 'boolean', received type '{}'".format(element_type)
        return 
        
        
    #Randomly select an appropriate fuzz value
    generated_boolean_value = generateASNBoolean()
    new_xer_node  = ET.SubElement(fuzz_element,generated_boolean_value)
    
        
    #Check to see if element has a default value. If so use that
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in fuzz_element_boolean.attrib.keys() :
        #Check if the element is marked not fuzzable. If so, use the default
        if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in fuzz_element_boolean.attrib.keys()  :
            if fuzz_element_boolean.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB].lower() != BOOL_TRUE_STRING :                       
                element_default_value = fuzz_element_boolean.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]
                new_xer_node  = ET.SubElement(fuzz_element,element_default_value)        

    #Rename node name from 'fuzz_element' to $element_name
    fuzz_element.tag = element_name
    
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
     
     
    
    
##
# @brief Fuzzes an asn element of type null based on the attributes of the fuzz_element node
# @param  fuzz_element_null: type of element
def fuzzASNNull(fuzz_element_null):
    fuzz_element = fuzz_element_null
    
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
    
    #Make sure the fuzz element is of type enumerated
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_NULL :
        print "Error: Expecting to fuzz element of type 'null', received type '{}'".format(element_type)
        return 

    
    #Get child nodes of fuzz_element
    child_node_list = []
    for enum_node in fuzz_element:
        child_node_list.append(enum_node)        
      
    #Remove the child nodes of fuzz element   
    for enum_node in child_node_list:
        fuzz_element.remove(enum_node)
          
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
   
    fuzz_element.tag = element_name
   
    
##
# @brief Handles unsupported fuzz element types
# @param  fuzz_element_not_supported: type of element   
def fuzzTypeNotSupported(fuzz_element_not_supported):
    fuzz_element = fuzz_element_not_supported
    
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
    
    print "WARNING: Node with name '{}' and type '{}' is not currently supported".format(element_name,element_type)
    
    
    #Get child nodes of fuzz_element
    child_node_list = []
    for enum_node in fuzz_element:
        child_node_list.append(enum_node)        
      
    #Remove the child nodes of fuzz element   
    for enum_node in child_node_list:
        fuzz_element.remove(enum_node)
        
    
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
   
    fuzz_element.tag = element_name


##
# @brief Fuzzes an asn element of type enumerated based on the attributes of the fuzz_element node
# @param  fuzz_element_null: type of element
def fuzzASNEnumerated(fuzz_element_enumerated): 

    fuzz_element = fuzz_element_enumerated

    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME] 
    
    #Make sure the fuzz element is of type enumerated
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_ENUM :
        print "Error: Expecting to fuzz element of type 'enumerated', received type '{}'".format(element_type)
        return 
        
    #Get the possible enum values, which are represented as child element nodes        
    enum_list = []    
    child_node_list = []
    for enum_node in fuzz_element:
        enum_list.append(enum_node.attrib["value"]) # add enum to list
        child_node_list.append(enum_node)
        
        
        
        
    #Randomly select an appropriate fuzz value from the child elements and append to enum_list          
    enum_value = generateASNEnumerated(enum_list) 
        
    #Check to see if element has a default value. If so use that
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in fuzz_element.attrib.keys() :
         #Check if the element is marked not fuzzable. If so, use the default
        if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in fuzz_element.attrib.keys()  :
            if fuzz_element.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB].lower() != BOOL_TRUE_STRING :                       
                default_enum_value = fuzz_element.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]   
                #Make sure the 'Default' enum specified is actually valid. If not, use a randomly generated enum
                if default_enum_value not in enum_list :
                    print "Warning...Specified default enum value '{}' is not a valid enum. Using '{}' instead".format(default_enum_value, enum_value)
                else :
                    enum_value = default_enum_value
    

                
    #Check for special case where element does not have a name
    if not element_name :
        fuzz_element.tag = enum_value
        fuzz_element.text = ""
    
    else :
        #Rename node name from 'fuzz_element' to $element_name
        fuzz_element.tag = element_name
        
        #Get the enum value, which are stored as a child node of fuzz_element                 
        new_xer_node  = ET.SubElement(fuzz_element,enum_value)
        
        
    #Remove the child nodes of fuzz element   
    for enum_node in child_node_list:
        fuzz_element.remove(enum_node)        
    
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
         
    return         
            

##
# @brief Fuzzes an asn element of type integer based on the attributes of the fuzz_element node
# @param  fuzz_element_integer: type of element
def fuzzASNInteger(fuzz_element_integer): 
 
    element_name = fuzz_element_integer.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element_integer.attrib[FUZZ_ELEMENT_ASN_TYPE]
    #element_isOptional =  fuzz_element_integer.attrib[FUZZ_ELEMENT_ASN_OPTIONAL]
    
    
    #Make sure the fuzz element is of type integer
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_INTEGER :
        print "Error: Expecting to fuzz element of type 'integer', received type '{}'".format(element_type)
        return 
        
        
    #Randomly select a fuzz value within min and max range
    element_min_value = DEFAULT_MIN_INT_VALUE
    element_max_value = DEFAULT_MAX_INT_VALUE
    
    if FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB in fuzz_element_integer.attrib.keys() :
        element_min_value = int(fuzz_element_integer.attrib[FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB])
        
    if FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB in fuzz_element_integer.attrib.keys() :
        element_max_value = int(fuzz_element_integer.attrib[FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB])
        
    #Generate fuzzed integer value and insert into the text of element
    generated_integer =  generateASNInteger(element_min_value,element_max_value)    
    fuzz_element_integer.text = str(generated_integer)     
        
    #Check to see if element has a default value. If so use that
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in fuzz_element_integer.attrib.keys() :
       if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in fuzz_element_integer.attrib.keys()  :
            #Check if the element is marked not fuzzable. If so, use the default
            if fuzz_element_integer.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB].lower() != BOOL_TRUE_STRING :                       
                element_default_value = int(fuzz_element_integer.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB])
                fuzz_element_integer.text = str(element_default_value)                 
    
    #Rename node name from 'fuzz_element' to $element_name
    fuzz_element_integer.tag = element_name
    
    #Remove the fuzz_element attributes
    if fuzz_element_integer.attrib:
        for key in fuzz_element_integer.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element_integer.attrib.pop(key)
            
            
    
    
    #print "Succesfully fuzzed  element '{}' with value '{}'\n".format(element_name,generated_integer)    
    return 
    
   
##
# @brief Fuzzes an asn element of type octet string based on the attributes of the fuzz_element node
# @param  fuzz_element_octet_string: type of element
def fuzzASNOctetString(fuzz_element_octet_string):
    fuzz_element = fuzz_element_octet_string
    
    #Get element's name and type
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
    
    #Make sure the fuzz element is of type Octet String
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_OCTETSTRING :
        print "Error: Expecting to fuzz element of type 'octet_string', received type '{}'".format(element_type)
        return 

    
    
    
    #DEFAULT VALUES
    element_min_size = 0
    element_max_size = 100
    
    #Randomly select an appropriate fuzz value    
    if FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB in fuzz_element.attrib.keys(): 
        element_min_size = int(fuzz_element.attrib[FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB])
        element_max_size = int(fuzz_element.attrib[FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB])
                    
    #Generate fuzzed bit_string  and insert into the text of element
    generated_string =  generateASNOctetString(element_min_size,element_max_size)
    fuzz_element.text = generated_string
    
    
    #Check to see if element has a default value. 
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in fuzz_element.attrib.keys() :
        if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in fuzz_element.attrib.keys()  :
            #Check if the element is marked not fuzzable. If so, use the default
            if fuzz_element.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB].lower() != BOOL_TRUE_STRING :                               
                element_default_value = fuzz_element.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]
                fuzz_element.text = str(element_default_value) 
        

        
        
    #Rename node name from 'fuzz_element' to $element_name
    fuzz_element.tag = element_name
    
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
        
    
    
    return

##
# @brief Fuzzes an asn element of type bit string based on the attributes of the fuzz_element node
# @param  fuzz_element_bit_string: type of element
def fuzzASNBitString(fuzz_element_bit_string): 

    fuzz_element = fuzz_element_bit_string
 
    element_name = fuzz_element.attrib[FUZZ_ELEMENT_ASN_NAME]
    element_type = fuzz_element.attrib[FUZZ_ELEMENT_ASN_TYPE]
    #element_isOptional =  fuzz_element.attrib[FUZZ_ELEMENT_ASN_OPTIONAL]
    
    
    #Make sure the fuzz element is of type bitstring
    if  not element_type  == PRIMITIVE_ASN_FUZZ_TYPE_BITSTRING :
        print "Error: Expecting to fuzz element of type 'bit_string', received type '{}'".format(element_type)
        return 
        
        
    
    #DEFAULT VALUES
    element_min_size = 10
    element_max_size = 15
    
    
    #Randomly select an appropriate fuzz value    
    if FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB in fuzz_element.attrib.keys(): 
        element_min_size = int(fuzz_element.attrib[FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB])
        element_max_size = int(fuzz_element.attrib[FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB])
                    
    #Generate fuzzed bit_string  and insert into the text of element
    generated_string =  generateASNBitString(element_min_size,element_max_size)
    fuzz_element.text = generated_string
    
    
    #Check to see if element has a default value. If so use that
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in fuzz_element.attrib.keys() :
        if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in fuzz_element.attrib.keys()  :
            #Check if the element is marked not fuzzable. If so, use the default
            if fuzz_element.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB].lower() != BOOL_TRUE_STRING :                                       
                element_default_value = fuzz_element.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]
                fuzz_element.text = str(element_default_value) 
                 
    #Rename node name from 'fuzz_element' to $element_name
    fuzz_element.tag = element_name
    
    #Remove the fuzz_element attributes
    if fuzz_element.attrib:
        for key in fuzz_element.attrib.keys():
            #print "Removing fuzz element attribute '{}' from '{}'".format(repr(key), element_name)
            fuzz_element.attrib.pop(key)
                                    
    return 
    
    
def testHarness():
 
    print "\n==============BEGIN TEST=================\n"
     
    primitive_fuzz_element_message_in_path = DEFAULT_PRIMITIVE_FUZZ_ELEMENT_MESSAGE_IN_PATH
    xer_message_out_path = DEFAULT_XER_MESSAGE_OUT_PATH
    
    primitiveElementFuzzer(primitive_fuzz_element_message_in_path , xer_message_out_path)
    
    print "\n===============END TEST================="


def main() :

    print "\n*********Primitive Element Fuzzer (Release v1)*********\n"    
    
    testHarness()
    

if __name__ == "__main__" :    
    main()



