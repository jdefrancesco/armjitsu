################################################################################
################################################################################
#
# FILE: XER2FuzzableMessage.py (version 1)
#
# DESCRIPTION: Takes as input an XER message and converts it to a fuzzable message that
#               can be ingested into the 'PrimitiveElementFuzzer'
#
# LIMITATIONS: Python2.7
#
#
# AUTHOR: Malachi Jones (mjones30)
#
################################################################################


import sys, os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import getpass
from FuzzElementPrimitive import *
from constants import *
import re


#===========================CONFIGURABLE VALUES ===========================================
USER_NAME = getpass.getuser()
XSD_DIR_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/25.331_xsd/".format(USER_NAME)
XER_MESSAGE_IN_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/xer_messages/rrcConnectionSetupCompleteMessage.xml".format(USER_NAME)
POPULATED_MESSAGE_TEMPLATE_OUT_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/PopulatedTemplates/populatedTemplate.xml".format(USER_NAME)
XER_TEMPLATE_DIR = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/templates/".format(USER_NAME)
MESSAGE_TYPE = 'UL-DCCH-Message'
#============================END CONFIGURABLE VALUES=======================================


#===================================GLOBALS=================================================
XSD_TREE = None  #Reference to XSD tree
MESSAGE_TEMPLATE_TREE_ROOT = None  #Type of message (e.g. UL-DCCH vs DL-CCCH)
MESSAGE_TEMPLATE_PARENT_MAP = None

XER_MESSAGE_TREE_ROOT = None
XER_MESSAGE_PARENT_MAP = None 


XER_ELEMENT_NAME_DIC = None  #Dictionary that stores information about the values of primitives in an xer message
#==================================END GLOBALS==============================================


#==================================CLASS DEFINITIONS========================================
class XERNodeLookupElement :
    def __init__(self):
        self.isUnique = None        
        self.value = None
        self.childNodeList = []
        self.xer_elementList = []
        
        
class XERElement :
    def __init__(self):     
        self.ancestorList = []
        self.value = None
        self.childNodeList = []
 

#===================================END CLASS DEFINITIONS==============================================



def initializeXERNodeLookupTable(xer_message_in_path, xer_root = None) :

    global XER_ELEMENT_NAME_DIC
   
    #Check to see if lookup table already initialized
    if XER_ELEMENT_NAME_DIC != None and xer_root == None  :
        print "XERNode Lookup table already initialized"
        return
        
    elif XER_ELEMENT_NAME_DIC == None and xer_root == None :
        XER_ELEMENT_NAME_DIC = dict()
        xer_root =getXERMessageTreeRoot(xer_message_in_path)
        
    
    if xer_root == None :
        return
        
    else :
        xer_element_name = getXERNodeName(xer_root)

        #print "Xer element name '{}'".format(xer_element_name)

       #Check if element name already in dictionary
        if xer_element_name in  XER_ELEMENT_NAME_DIC.keys() :
            #Element name not unique
            XER_ELEMENT_NAME_DIC[xer_element_name].isUnique = False   

        else :
            #Unique element
            xer_lookup_element = XERNodeLookupElement()
            xer_lookup_element.isUnique = True
            XER_ELEMENT_NAME_DIC[xer_element_name] = xer_lookup_element
            
            
        xer_lookup_element = XER_ELEMENT_NAME_DIC[xer_element_name]
        
        xer_element= XERElement()            
        xer_element.ancestorList = getXERNodeAncestorList(xer_root)
        if xer_root.text :
            xer_element.value = xer_root.text.strip()
        
        for childXerNode in xer_root :
            xer_element.childNodeList.append(childXerNode)        
            initializeXERNodeLookupTable(None,childXerNode )
        
        
        xer_lookup_element.xer_elementList.append(xer_element)
        
    return
                                
            
            
    
##
# @brief Recursively gets the name of the ancestors of the fuzz node
# @param  simpleTypeName: name of simple type
# @return nodename: xsd xml node            
def getFuzzNodeAncestorList(fuzz_node, ancestorList= None):
    global MESSAGE_TEMPLATE_PARENT_MAP
    if ancestorList == None :
        ancestorList = []
        
    if fuzz_node in MESSAGE_TEMPLATE_PARENT_MAP :
        parent_node =  MESSAGE_TEMPLATE_PARENT_MAP[fuzz_node]
        
        parent_node_name = getFuzzNodeName(parent_node)
        
        if parent_node_name != None:
            #Only append as ancestor if the parent string is nonempty
            if parent_node_name != "" :
                ancestorList.append(parent_node_name)
            getFuzzNodeAncestorList(parent_node,ancestorList)
                
    return ancestorList
    
    
def getXERNodeAncestorList(xer_node, ancestorList= None) :
    global XER_MESSAGE_PARENT_MAP
    
    if ancestorList == None :
        ancestorList = []
        
    if xer_node in XER_MESSAGE_PARENT_MAP :
        parent_node =  XER_MESSAGE_PARENT_MAP[xer_node]        
        parent_node_name = getXERNodeName(parent_node)
        
        if parent_node_name != "message" :       
            ancestorList.append(parent_node_name)
            getXERNodeAncestorList(parent_node,ancestorList)
                
    return ancestorList
 
def getXERNodeName( xer_node) :
    return xer_node.tag
  
    
def getFuzzNodeName(fuzz_node) :
    fuzz_node_name = None
    
    if FUZZ_ELEMENT_NODE_NAME_ATTRIB in fuzz_node.attrib.keys() :
        fuzz_node_name =  fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
        
    return fuzz_node_name
                
def isFuzzNodePrimitive(fuzz_node):
    fuzz_node_type = fuzz_node.attrib[FUZZ_ELEMENT_NODE_TYPE_ATTRIB]
    if fuzz_node_type in PRIMITIVE_TYPE_LIST :
        return True
    else :
        return False
    

def populateTemplateWithXERValues(xer_message_in_path, populated_template_out_path, xer_template_dir, message_type) :

    message_name = getMessageName(xer_message_in_path)    
    print "XER Message '{}' will be used to populate template".format(message_name)
    
    
    message_template_path = getMessageTemplatePath(xer_template_dir, message_name, message_type)
    
    print "Message template path {}".format(message_template_path)
    
    #Initialize lookup table
    initializeXERNodeLookupTable(xer_message_in_path)
    
    
    #Get the root 
    message_template_tree_root =getMessageTemplateTree(message_template_path)
    

    #Iterate through fuzz nodes to modify default value
    for fuzz_node in message_template_tree_root.iter(FUZZ_ELEMENT_NODE_NAME):
    
        #Only consider fuzz nodes that are primitives
        if not isFuzzNodePrimitive(fuzz_node):
            continue
    
        if FUZZ_ELEMENT_NODE_NAME_ATTRIB in fuzz_node.attrib.keys() :
            fuzz_element_name = fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
            #print "Fuzz node '{}' is a primitive".format(fuzz_element_name)
            
        xer_element = getXERNodeElement(fuzz_node)               
        
        if xer_element:
            fuzz_node_type = getFuzzNodeType(fuzz_node)
        
            if fuzz_node_type == PRIMITIVE_ASN_FUZZ_TYPE_ENUM :
                enum_default =  xer_element.childNodeList[0].tag
                fuzz_node.set(FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB,enum_default)
                fuzz_node.set(FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB,BOOL_FALSE_STRING)
                

            elif  xer_element.value :
                fuzz_node.set(FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB, xer_element.value)
                fuzz_node.set(FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB,BOOL_FALSE_STRING)
            

    #convert xml object to string
    
    populated_template_string = ET.tostring(message_template_tree_root)
    
    #Need to remove the tabs and spaces so that when we call pretty print, it actually looks pretty
    populated_template_string = populated_template_string.replace('\t','').replace('\n','')
    
    xmls = xml.dom.minidom.parseString(populated_template_string)     
    populated_template_string = xmls.toprettyxml()
    

    f = open(populated_template_out_path, 'w')
    f.write(populated_template_string)
    f.close()
    
    return populated_template_string
   
##
# @brief Recursively construct a fuzzable message from the xer node (and children)
# @param  xer_node:  the xer node
def convertXERNode2FuzzableMessage(xer_node) :
    if isXERNodePrimitive(xer_node) :
        fuzzPrimitiveNode = getXERNodeDefinition(xer_node)
        #print "Obtained fuzz node  for '{}'".format(getXERNodeName(xer_node))
        #fuzzElementNode.prettyprint()
        
        enumDefaultValue = None
        
        
        if fuzzPrimitiveNode.type ==  PRIMITIVE_ASN_FUZZ_TYPE_ENUM:
            enumDefaultValue = xer_node[0].tag
        
        
        #Remove child node if exist
        child_node_list = []
        for enum_node in xer_node:            
            child_node_list.append(enum_node)
            
        for enum_node in child_node_list:
            xer_node.remove(enum_node)                
        
        
        xer_node_name = getXERNodeName(xer_node)
        
        xer_node_text  = xer_node.text
                
        
        #Set fuzz node tag
        xer_node.tag = FUZZ_ELEMENT_NODE_NAME
        
        #Type
        xer_node.set(FUZZ_ELEMENT_NODE_TYPE_ATTRIB, fuzzPrimitiveNode.type)
               
        #Name     
        xer_node.set(FUZZ_ELEMENT_NODE_NAME_ATTRIB, xer_node_name)  


        #Length
        if fuzzPrimitiveNode.minLength :
            xer_node.set(FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB, fuzzPrimitiveNode.minLength)       
        if fuzzPrimitiveNode.maxLength :
            xer_node.set(FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB, fuzzPrimitiveNode.maxLength)
         
        #Value 
        if fuzzPrimitiveNode.minValue :            
            xer_node.set(FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB, fuzzPrimitiveNode.minValue)            
        if fuzzPrimitiveNode.maxValue !=None :            
            xer_node.set(FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB, fuzzPrimitiveNode.maxValue)              
       
        
        #Fuzzable
        if fuzzPrimitiveNode.isFuzzable != None :
            xer_node.set(FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB, str(fuzzPrimitiveNode.isFuzzable))  
        
        if fuzzPrimitiveNode.type ==  PRIMITIVE_ASN_FUZZ_TYPE_ENUM:        
            #Populate Child enum value nodes
            for enum_child in fuzzPrimitiveNode.children :
                new_fuzz_primitive_node  = ET.SubElement(xer_node,FUZZ_ENUMERATED_VALUE_NODE_NAME)
                new_fuzz_primitive_node.set(FUZZ_ELEMENT_NODE_VALUE_ATTRIB, enum_child.value)
                
            #Set enum default value
            xer_node.set(FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB,enumDefaultValue)            
        
        else :
            #DefaultValue
            if  xer_node_text :            
                xer_node.set(FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB,xer_node_text)
                
                
        #Clear xer text
        xer_node.text = ""
        
        
        return
        
    for child_xer_node in xer_node :
        convertXERNode2FuzzableMessage(child_xer_node)
    
 
 
 
def isXERNodePrimitive(xer_node) :
    xer_node_name = getXERNodeName(xer_node)
    
    if XER_ELEMENT_NAME_DIC[xer_node_name].isUnique :
        return XER_ELEMENT_NAME_DIC[xer_node_name].isPrimitive
        
    else :
    
        xer_node_ancestorList = getXERNodeAncestorList(xer_node)
        
        #Find the definition that matches the ancestor of this node
        for xer_node in XER_ELEMENT_NAME_DIC[xer_node_name].xer_elementdefinitionList :
            xer_node_ancestorList = xer_node.ancestorList
            
            #if xer_node_name == "small":
            #    print "\n**********************************************"
            #    print "Length of xer_definition_ancestor:{}".format(len(xer_node_ancestorList))            
            #    print "Length of xer_node_ancestor:{}".format(len(xer_node_ancestorList))
            if len(xer_node_ancestorList) != len(xer_node_ancestorList) :                
                continue
            #check if all ancestors match all the ancestors match
            isMatch = True
            for i in range(len(xer_node_ancestorList)) :
                #if xer_node_name == "small":
                #    print "Comparing ancestors {} : {}".format(xer_node_ancestorList[i],xer_node_ancestorList[i])
                if xer_node_ancestorList[i] != xer_node_ancestorList[i] :
                    isMatch = False                    
                    
            if isMatch :
                return xer_node.isPrimitive
              
            #if xer_node_name == "small":
            #    print "**********************************************\n"
                    
        
        
        print "(isXERNodePrimitive) Warning: We couldn't find a match fore element name '{}'!!!".format(xer_node_name)
        
        #xer_node_ancestorList
        #if xer_node_name == 'small' :                
        #    print "\n****BEGIN Ancestors of '{}'".format(xer_node_name)
        #    for ancestor in xer_node_ancestorList :
        #        print "Ancestor -->{}".format(ancestor)                
        #                        
        #    print "****END Ancestors \n"
        
        return None
    
    
def getXERNodeElement(fuzz_node) :
    global XER_ELEMENT_NAME_DIC

    fuzz_node_name =getFuzzNodeName(fuzz_node)
    fuzz_node_ancestorList = getFuzzNodeAncestorList(fuzz_node)
    
    #print "Getting definition for xer node '{}'".format(fuzz_node_name)
    
    #Check if the element in template also exists in the XER 
    if fuzz_node_name not in XER_ELEMENT_NAME_DIC :
        #print "Fuzz node element '{}' not in XER".format(fuzz_node_name)
        return None
    
    
    if XER_ELEMENT_NAME_DIC[fuzz_node_name].isUnique :
        return XER_ELEMENT_NAME_DIC[fuzz_node_name].xer_elementList[0]
        
    else :        
        #Find the definition that matches the ancestor of this node
        for xer_element in XER_ELEMENT_NAME_DIC[fuzz_node_name].xer_elementList :
            xer_node_ancestorList = xer_element.ancestorList
            
            #print "\n**********************************************"
            #print "Length of xer_definition_ancestor:{}".format(len(xer_node_ancestorList))
            #print "Length of xer_node_ancestor:{}".format(len(xer_node_ancestorList))
            if len(xer_node_ancestorList) != len(fuzz_node_ancestorList) :                
                continue
            #check if all ancestors match all the ancestors match
            isMatch = True
            for i in range(len(xer_node_ancestorList)) :
                #print "Comparing ancestors {} : {}".format(xer_node_ancestorList[i],xer_node_ancestorList[i])
                if fuzz_node_ancestorList[i] != xer_node_ancestorList[i] :
                    isMatch = False                    
                    
            if isMatch :
                return xer_element
                
            #print "**********************************************\n"
                    
        
        
        #print "(getXERNodeDefinition) Warning: We couldn't find a match for element name '{}' because it most likely doesn't exist in XER!!!".format(fuzz_node_name)
        return None


def printNonUniqueNodeDefLookupTable():
    global XER_ELEMENT_NAME_DIC
    
    
    for element_name in XER_ELEMENT_NAME_DIC.keys() :    
        if not XER_ELEMENT_NAME_DIC[element_name].isUnique and XER_ELEMENT_NAME_DIC[element_name].isPrimitive:
        
            fuzz_element_type =XER_ELEMENT_NAME_DIC[element_name].fuzzElementNode.type
            print "NOT Unique primitive element name :'{}'  Type:'{}'".format(element_name,fuzz_element_type)
       

def printUniqueNodeDefLookupTable():
    global XER_ELEMENT_NAME_DIC
    
    
    for element_name in XER_ELEMENT_NAME_DIC.keys() :    
        if XER_ELEMENT_NAME_DIC[element_name].isUnique and XER_ELEMENT_NAME_DIC[element_name].isPrimitive:
        
            fuzz_element_type =XER_ELEMENT_NAME_DIC[element_name].fuzzElementNode.type
            print "Unique primitive element name :'{}'  Type:'{}'".format(element_name,fuzz_element_type)
        
 
def getXERMessageTreeRoot(xer_message_in_path):
    global XER_MESSAGE_TREE_ROOT
    global XER_MESSAGE_PARENT_MAP

    if XER_MESSAGE_TREE_ROOT != None : 
        return XER_MESSAGE_TREE_ROOT
    else :        
        tree = ET.parse(xer_message_in_path)
        XER_MESSAGE_TREE_ROOT = tree.getroot()
        
        XER_MESSAGE_PARENT_MAP = dict((c, p) for p in tree.getiterator() for c in p)
        
        return XER_MESSAGE_TREE_ROOT
 
 
def getMessageTemplatePath(xer_template_dir, message_name, message_type):
    return  xer_template_dir +message_name + '_' + message_type + '_' + MESSAGE_TEMPLATE_SUFFIX + XML_EXT
 
 
def getMessageTemplateTree(message_template_path) :
    global MESSAGE_TEMPLATE_TREE_ROOT
    global MESSAGE_TEMPLATE_PARENT_MAP

    if MESSAGE_TEMPLATE_TREE_ROOT != None : 
        return MESSAGE_TEMPLATE_TREE_ROOT
    else :        
            
        tree = ET.parse(message_template_path)
        MESSAGE_TEMPLATE_TREE_ROOT = tree.getroot()
        
        MESSAGE_TEMPLATE_PARENT_MAP= dict((c, p) for p in tree.getiterator() for c in p)
        
        return MESSAGE_TEMPLATE_TREE_ROOT
        
        
def getFuzzNodeType (fuzz_node) :
    return  fuzz_node.attrib[FUZZ_ELEMENT_NODE_TYPE_ATTRIB]
    
def getMessageName(xer_message_in_path):

    xer_message_root =getXERMessageTreeRoot(xer_message_in_path)
        
    #Message name is stored in the tag of the root's grandchild
    message_name =  xer_message_root[0][0].tag 
       
    return message_name

  
    
def testHarness():
    print "\n==============BEGIN TEST=================\n"
    
    xer_message_in_path = XER_MESSAGE_IN_PATH
    #fuzzable_message_out_path = FUZZABLE_MESSAGE_OUT_PATH
    populated_template_out_path = POPULATED_MESSAGE_TEMPLATE_OUT_PATH
    xer_template_dir = XER_TEMPLATE_DIR
    message_type = MESSAGE_TYPE
      
    
    populated_Template_String = populateTemplateWithXERValues(xer_message_in_path, populated_template_out_path, xer_template_dir, message_type)
    
    
    
    #printUniqueNodeDefLookupTable()
    
    #printNonUniqueNodeDefLookupTable()

        
    print "\n===============END TEST================="


def main():
    print "\n*********XER 2 Fuzzable Message  (version 1)*********\n"
        

    testHarness()

  


if __name__ == "__main__" :    
    main()
