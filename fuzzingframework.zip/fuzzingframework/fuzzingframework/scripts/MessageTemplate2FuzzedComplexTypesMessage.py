################################################################################
################################################################################
#
# FILE: MessageTemplate2FuzzedComplexTypesMessage.py (version 4)
#
# DESCRIPTION: Takes as input a message template and performs the stage 1 
#              construction of the XML encoded rules (XER). During this stage,
#              complex types that include choices, sequences, and lists are fuzzed. 
#              At the completion of stage 1, only  primitives types remain and will
#              need to be appropriately fuzzed to generate a valid XER.
#              
#
# LIMITATIONS: Python2.7
#
#
# AUTHOR: Malachi Jones (mjones30)
#
################################################################################


import sys, os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import getpass
from FuzzElementPrimitive import *
from constants import *


#===========================CONFIGURABLE VALUES ===========================================
USER_NAME = getpass.getuser()
DEFAULT_XER_MESSAGE_TEMPLATE_IN_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/templates/exampleComplexTemplate.xml".format(USER_NAME)
#DEFAULT_XER_MESSAGE_TEMPLATE_IN_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/PopulatedTemplates/populatedTemplate.xml".format(USER_NAME)
DEFAULT_FUZZED_COMPLEX_TYPES_OUT_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/fuzzed/exampleFuzzedMessage.xml".format(USER_NAME)
#============================END CONFIGURABLE VALUES=======================================

#=======================================GLOBALS=============================================
MESSAGE_TYPE = None
#======================================END GLOBALS==========================================

#==================================CLASS DEFINITIONS========================================
  
class XER_Element:
    def __init__(self) :
        self.name = None
        self.text = None
        self.occurs = 1
        self.children = []
        self.fuzzElementPrimitive = None
        
    def prettyprint(self) :
        print "\n========XER Element Struct========"
        print "Name: '{}'".format(self.name) 
        print "Text: '{}'".format(self.text)    
        print "Children:"
        for child in self.children :
            #print "\t{}".format(child.name)       
            child.prettyprint()
        print "========END XER Element Struct======\n"
   
    ##
    # @brief Recursively creates an XER tree representation from the fuzz element node
    # @member xer_tree_root: xer parent node   
    def createXERTree(self, xer_tree_root = None) :
        global MESSAGE_TYPE
        appendASNHeader=False
        if(xer_tree_root == None):        
            xer_tree_root = ET.Element(XER_MESSAGE_NODE_NAME)
            appendASNHeader = True
        
        #XER element is a primitive        
        if not self.fuzzElementPrimitive == None:            
            return  self.fuzzElementPrimitive.createFuzzTree(xer_tree_root)
          
        #Special condition where ASN element does not have a name 
        # Example: Child of ue-RATSpecificCapability in rrcConnectionSetupComplete
        if self.name == "" or self.name == None :
            #Directly append children of this element to this elements parent            
            for child in self.children :
                if child != None:
                    child.createXERTree(xer_tree_root)
                    
       
        else: 
            xer_node_name = self.name    
            xer_node_text = self.text
            
            
            #if(self.occurs > 1) :
            #    print "(List) Name:{}  Occurances:{}".format(self.name,self.occurs)
            
                                                        
            #Create xer node and append to root       
            new_xer_node  = ET.SubElement(xer_tree_root,xer_node_name)
            new_xer_node.text = xer_node_text
            
            #Recursively add children to the tree           
            #Top loop for sequences that occurances that can be > 1
            for i in range(self.occurs):            
                for child in self.children :
                    if child != None:
                        #print "Adding child '{}' to tree".format(child.name)
                        child.createXERTree(new_xer_node)
                
            if appendASNHeader :
                xer_prev_root = xer_tree_root
                xer_tree_root =  ET.Element(MESSAGE_TYPE)
                xer_tree_root.append(xer_prev_root)
            
            
        return xer_tree_root
      
    # @brief Get the pretty print xml string
    # @return  xml string    
    def getPrettyPrintXMLString(self):
        xer_tree_root = self.createXERTree()
        
        #print "Fuzz tree root-->{} {}".format(xer_tree_root.tag, xer_tree_root.attrib)
        
        xer_tree_string = ET.tostring(xer_tree_root)
        
        #print "Fuzz tree string {}".format(xer_tree_string)
        xmls = xml.dom.minidom.parseString(xer_tree_string)     
        pretty_xer_xml_tree_string = xmls.toprettyxml()
        
        return pretty_xer_xml_tree_string
     
    ##
    # @brief Get the pretty print xml string 
    def prettyprintFuzzTree(self):
        print "{}".format(self.getPrettyPrintXMLString())
        
    ##
    # @brief Write xml tree to specified file
    # @param  xml_file_path path to write xml file to
    def writeTree2FileAsXML(self,xml_file_path) :    
        fuzz_tree_xml_string = self.getPrettyPrintXMLString()        
        f = open(xml_file_path, 'w')
        f.write(fuzz_tree_xml_string)
        f.close()
        #print "Tree written as XML to path: {}".format(xml_file_path)
        
                  
#===================================END CLASS DEFINITIONS==============================================

##
# @brief Creates a XER node of a primitive fuzz types
# @param  primitive_fuzz_node: primitive fuzz tree node
# @return xer_element: xer tree node
def createXERNodeForPrimitiveFuzzType(primitive_fuzz_node):
    xer_element = XER_Element()
    
    
    #Create the fuzz element primitive object
    fuzz_element_primitive = FuzzElementPrimitive()    
    fuzz_element_primitive.type = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_TYPE_ATTRIB]
    
    
    #Get the name of the primtive node
    if FUZZ_ELEMENT_NODE_NAME_ATTRIB in  primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.name = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
        
    else :
        fuzz_element_primitive.name = None
    

    # Get and set the attributes of primitive node
    if FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB in primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.minLength = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB]
    
    if FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB in primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.maxLength = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB]
    
    if FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.maxValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB]
        
    if FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.minValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB]    
        
    if FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB in primitive_fuzz_node.attrib.keys() :
        fuzz_element_primitive.defaultValue = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_DEFAULT_VALUE_ATTRIB]
    
    if FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB in primitive_fuzz_node.attrib.keys() :       
        fuzz_element_primitive.isFuzzable = primitive_fuzz_node.attrib[FUZZ_ELEMENT_NODE_IS_FUZZABLE_ATTRIB]
    
    #Create child nodes for ENUM fuzz element
    if fuzz_element_primitive.type == PRIMITIVE_ASN_FUZZ_TYPE_ENUM:
        for child in primitive_fuzz_node.findall(FUZZ_ENUMERATED_VALUE_TYPE) :
            fuzz_child_primitive = FuzzElementPrimitive() 
            fuzz_child_primitive.type = FUZZ_ENUMERATED_VALUE_TYPE
            fuzz_child_primitive.value = child.attrib[XSD_VALUE_ATTRIBUTE]
            fuzz_element_primitive.children.append(fuzz_child_primitive)
            
            
    
    #print "#######Primitive name:{}  type:{}######".format(fuzz_element_primitive.name, fuzz_element_primitive.type)
    
    xer_element.name = fuzz_element_primitive.name     
    xer_element.fuzzElementPrimitive = fuzz_element_primitive
     
     
     
     
    return xer_element 

##
# @brief Recursively creates an xer node of a choice fuzz element. 
# @param  choice_fuzz_node: choice fuzz node
# @return xer_element: xer element that represents choice node    
def createXERNodeForChoiceFuzzType(choice_fuzz_node) :
    from random import randint
    
    
    xer_element = XER_Element()
    
    #Get and set the name of the xer element
    if FUZZ_ELEMENT_NODE_NAME_ATTRIB in  choice_fuzz_node.attrib.keys() :
        xer_element.name = choice_fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
        
    else :
        xer_element.name = None
            
    
    fuzzElementNodeList = choice_fuzz_node.findall(FUZZ_ELEMENT_NODE_TAG)
    
    #Randomly pick one of the children of choice element
    num_choices  = len(fuzzElementNodeList)
    rand_choice_index = randint(0,num_choices-1)   
    fuzzChild = fuzzElementNodeList[rand_choice_index]
        
    
    #Append randomly select child to children list
    xer_child_element =  convertFuzzNode2XERNode(fuzzChild)
    xer_element.children.append(xer_child_element)
       

    return xer_element

##
# @brief Recursively creates an xer node of a sequence fuzz element. 
# @param  sequence_fuzz_node: sequence fuzz node
# @return xer_element: xer element that represents sequence node       
def createXERNodeForSequenceFuzzType(sequence_fuzz_node):
    
    xer_element = XER_Element()
    
    if FUZZ_ELEMENT_NODE_NAME_ATTRIB in  sequence_fuzz_node.attrib.keys() :
        xer_element.name = sequence_fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]
        
    else :
        xer_element.name = None
        
    minOccurs = getFuzzNodeMinOccurs(sequence_fuzz_node)    
    maxOccurs = getFuzzNodeMaxOccurs(sequence_fuzz_node)  
    
    
    #@TODO Need to expand logic here to randimize occur based on minOccurs and maxOccurs
    #      Currently defaults to the minOccurs
    xer_element.occurs = minOccurs
    
    #Have all optional elements occur at least once.
    if xer_element.occurs == 0 :
        xer_element.occurs = 1
        
            
    fuzzElementNodeList = sequence_fuzz_node.findall(FUZZ_ELEMENT_NODE_TAG)
    
    #Recursively evaluates the children of the current element
    for fuzzChild in fuzzElementNodeList :        
        xer_child_element =  convertFuzzNode2XERNode(fuzzChild)
        xer_element.children.append(xer_child_element)

    return xer_element

##
# @brief Get the maximum number of occurences for the fuzz element 
# @param  fuzz_node: fuzz node
# @return maxOccurs: maximum number of occurences
def getFuzzNodeMaxOccurs(fuzzNode):
    maxOccurs = int(fuzzNode.attrib[XSD_ELEMENT_MAX_OCCUR_ATTRIBUTE])
    
    return maxOccurs
    
   
##
# @brief Get the minimum number of occurences for the fuzz element 
# @param  fuzz_node: fuzz node
# @return minOccurs: minimum number of occurences
def getFuzzNodeMinOccurs(fuzzNode):
    minOccurs = int(fuzzNode.attrib[XSD_ELEMENT_MIN_OCCUR_ATTRIBUTE])
    
    return minOccurs
    
##
# @brief Recursively converts a fuzz node to an xer node
# @param  fuzzRootNode: fuzz root node
# @return xer_element : xer root element
def convertFuzzNode2XERNode(fuzzRootNode):
    global MESSAGE_TYPE
    
    xer_element = None
    
    #Fuzz tree root node
    if fuzzRootNode.tag == FUZZ_TREE_NODE_TAG :
       
        fuzzElementNodeList = fuzzRootNode.findall(FUZZ_ELEMENT_NODE_TAG)
        
        MESSAGE_TYPE = fuzzRootNode.attrib[FUZZ_TREE_ROOT_MESSAGE_TYPE_ATTRIB]
        
        #Fuzz tree root should only have 1 child
        if len(fuzzElementNodeList) > 1 :
            print "ERROR: Fuzz tree root node should only have 1 child"
            return None
        
        fuzzElementChild = fuzzElementNodeList[0] 
        
        return convertFuzzNode2XERNode(fuzzElementChild)
        
    else :
    
        fuzz_element_type =  fuzzRootNode.attrib[FUZZ_ELEMENT_NODE_TYPE_ATTRIB]
        
        #FUZZ TYPE --> "SEQUENCE"
        if fuzz_element_type == FUZZ_ELEMENT_TYPE_SEQUENCE :               
            xer_element = createXERNodeForSequenceFuzzType(fuzzRootNode)
        
        #FUZZ TYPE --> "CHOICE"
        elif fuzz_element_type == FUZZ_ELEMENT_TYPE_CHOICE :
            xer_element = createXERNodeForChoiceFuzzType(fuzzRootNode)
            
            
        #FUZZ_TYPE --> "Primitive"    
        else:
            xer_element = createXERNodeForPrimitiveFuzzType(fuzzRootNode)

        return xer_element

##
# @brief Get the fuzz tree root node from message template located at specified file path
# @param  messageTemplateFilePath:  message template file path
# @return root : fuzz tree root node    
def getFuzzTreeRootNodeFromMessageTemplate(messageTemplateFilePath) :
    tree = ET.parse(messageTemplateFilePath)
    root = tree.getroot()
    
    
    return root

##    
# @brief Takes as input a message template and fuzzes the complex types    
# @param  xer_message_template_in_path:  message template file path
# @param  fuzzed_complex_types_out_path:  fuzzed complex type message output path
def convertTemplate2FuzzedComplexTypesMessage(xer_message_template_in_path = None, fuzzed_complex_types_out_path = None) :
    
    #Check if message template input path specified. If not, use default
    if xer_message_template_in_path == None :
        print "Using default xer message template path: '{}'".format(DEFAULT_XER_MESSAGE_TEMPLATE_IN_PATH)
        xer_message_template_in_path = DEFAULT_XER_MESSAGE_TEMPLATE_IN_PATH
        
    if fuzzed_complex_types_out_path == None :
        print "Using default fuzzed complex types out path: '{}'".format(DEFAULT_FUZZED_COMPLEX_TYPES_OUT_PATH)
        fuzzed_complex_types_out_path = DEFAULT_FUZZED_COMPLEX_TYPES_OUT_PATH
                    
    fuzzTreeRoot = getFuzzTreeRootNodeFromMessageTemplate(xer_message_template_in_path)
    
    xer_node = convertFuzzNode2XERNode(fuzzTreeRoot)         
    
    xer_node.writeTree2FileAsXML(fuzzed_complex_types_out_path)

def testHarness():
    print "\n==============BEGIN TEST=================\n"
    
    xer_message_template_in_path = DEFAULT_XER_MESSAGE_TEMPLATE_IN_PATH
    fuzzed_complex_types_out_path = DEFAULT_FUZZED_COMPLEX_TYPES_OUT_PATH
    convertTemplate2FuzzedComplexTypesMessage(xer_message_template_in_path,fuzzed_complex_types_out_path)
        
    print "\n===============END TEST================="


def main():
    print "\n*********Message Template 2 Fuzzed Complex Types Message  (Release v1)*********\n"
        
    testHarness()

  


if __name__ == "__main__" :    
    main()

