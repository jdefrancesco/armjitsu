#!/usr/bin/env python

import os

sections = os.listdir(".")

print "[MMUPagesList]"
for file in sections:
    if file.startswith("mem_"):
        print file[0:12]

print ""

for file in sections:
    if file.startswith("mem_"):
		print "[" + file[0:12] + "]"
		print "FILE=memory/" + file
		print "TYPE=binary"
		print "PROTECTION=" + file[22:26]
		print "BASEADDRESS=0x" + file[4:12]
		print ""
