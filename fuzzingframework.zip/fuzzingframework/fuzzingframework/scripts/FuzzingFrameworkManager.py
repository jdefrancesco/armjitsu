################################################################################
################################################################################
#
# FILE: FuzzingFrameworkManager.py
#
# DESCRIPTION: Generates fuzzed XER messages given the messages to fuzz as 
#              arguments
#              To get usage information, pass in the argurment '-h' 
#              Example: $python FuzzingFrameworkManager.py  -h    
#              Alternatively, it can be run with no arguments, where defaults will 
#              be implicilty used   
#
# LIMITATIONS: Python2.7
#
#
# AUTHOR: Malachi Jones (mjones30)
#
################################################################################

#import rrcConvert
import argparse
import sys
import os.path
import subprocess
import shlex
import struct
import gc
import time
import random
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime
from constants import *
from XSD2MessageTemplate import generateMessageTemplate
from MessageTemplate2FuzzedComplexTypesMessage import convertTemplate2FuzzedComplexTypesMessage
from PrimitiveElementFuzzer import primitiveElementFuzzer
from asnUtils import displayFuzzableMessages, getNameOfXERMessage, getMessageNameofTemplate
from PopulateTemplateWithXERValues import populateTemplateWithXERValues
from multiprocessing import Process
# import rrcConvert
import importlib
import argparse
import os.path
import random
import shutil
import sys
import time
import threading
import xml.etree.ElementTree as ET
from datetime import datetime
from multiprocessing import Process
from binascii import unhexlify

from MessageTemplate2FuzzedComplexTypesMessage import convertTemplate2FuzzedComplexTypesMessage
from PopulateTemplateWithXERValues import populateTemplateWithXERValues
from PrimitiveElementFuzzer import primitiveElementFuzzer
from XSD2MessageTemplate import generateMessageTemplate
from asnUtils import displayFuzzableMessages, getNameOfXERMessage, getMessageNameofTemplate
from constants import *

#===========================CONFIGURABLE VALUES ===========================================
FUZZING_FRAMEWORK_ROOT_PATH = "/var/ipaccess/python/fuzzingframework/"
DEFAULT_UMTS_XSD_FILE_PATH = FUZZING_FRAMEWORK_ROOT_PATH+"/marben_xsds/UMTS.xsd"
DEFAULT_LTE_XSD_FILE_PATH = FUZZING_FRAMEWORK_ROOT_PATH+"/marben_xsds/LTE.xsd"
DEFAULT_UMTS_MASTER_TEMPLATES_PATH = FUZZING_FRAMEWORK_ROOT_PATH + "/umts_master_templates/"
DEFAULT_LTE_MASTER_TEMPLATES_PATH = FUZZING_FRAMEWORK_ROOT_PATH + "/lte_master_templates/"
DEFAULT_MESSAGE_LIST = ['rrcConnectionSetupComplete']
DEFAULT_MESSAGE_TYPE = 'UL-DCCH-Message'
DEFAULT_NUMBER_STAGE_1_FUZZED_MESSAGES = 20
DEFAULT_MAX_NUMBER_FUZZED_MESSAGES= 500
FOLDER_FULL_SLEEP_TIMEOUT = 5
DEFAULT_ARMULATOR_INSTANCES = 1
DEFAULT_ARMULATOR_TIMEOUT = 3000
DEFAULT_ARMJITSU_INSTANCES = 1
DEFAULT_ARMJITSU_TIMEOUT = 3000
#============================END CONFIGURABLE VALUES=======================================


#==============================CONSTANTS===========================================
STAGE_1_FUZZING_OUT_DIR_PATH =FUZZING_FRAMEWORK_ROOT_PATH+".Stage1Fuzzing/"
STAGE_2_FUZZING_OUT_DIR_PATH =FUZZING_FRAMEWORK_ROOT_PATH+".Stage2Fuzzing/"
STAGE_3_FUZZING_OUT_DIR_PATH =FUZZING_FRAMEWORK_ROOT_PATH+".Stage3Fuzzing/"
FUZZED_UPER_MESSAGES_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH +"/fuzzed_uper_messages/"
CONVERT_XER_2_UPER_BIN_PATH = FUZZING_FRAMEWORK_ROOT_PATH +"bin/rrc-dump"
POPULATED_TEMPLATES_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH + "/populated_templates/"
ARMULATOR_FUZZING_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH + ".ArmulatorFuzzing/"
ARMULATOR_DIR_PATH = "armulator/"
ARMULATOR_RESULTS_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH + "armulator_results/"
ARMJITSU_FUZZING_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH + ".ArmjitsuFuzzing/"
ARMJITSU_DIR_PATH = "armjitsu/"
ARMJITSU_RESULTS_DIR_PATH = FUZZING_FRAMEWORK_ROOT_PATH + "armjitsu_results/"
SUPPORTED_UMTS_MESSAGE_TYPES = ['DL-DCCH-Message', 'UL-DCCH-Message', 'DL-CCCH-Message', 'UL-CCCH-Message']
SUPPORTED_LTE_MESSAGE_TYPES = ['DL-DCCH-Message', 'UL-DCCH-Message', 'DL-CCCH-Message', 'UL-CCCH-Message']
SUPPORTED_FUZZ_TYPES = ['UMTS', 'LTE']
#============================END CONSTANTS=======================================

#===================================GLOBALS=================================================
XSD_FILE_PATH = None
MASTER_TEMPLATE_DIR_PATH = None
MESSAGES2FUZZ = None
MESSAGE_TYPE = None
THREADS  = []
EXIT_THREADS = False
DISPLAY_FUZZABLE_MESSAGES = None
MAX_NUMBER_FUZZED_MESSAGES = None
XER_FILE_PATH_FOR_POPULATING = None
POPULATED_TEMPLATE_FILE_PATH = None
NUMBER_STAGE_1_FUZZED_MESSAGES = None
FUZZ_TYPE = None
RRCCONVERT = None
FUZZ_WITH_ARMULATOR = None
MAX_ARMULATOR_INSTANCES = None
ARMULATOR_TIMEOUT = None
ARMULATOR_JOB_RESULTS_DIR_PATH = None
ARMULATOR_USE_SNAPSHOT = None
FUZZ_WITH_ARMJITSU = None
MAX_ARMJITSU_INSTANCES = None
ARMJITSU_TIMEOUT = None
ARMJITSU_INI = None
ARMJITSU_INI_VALUES = None
ARMJITSU_JOB_RESULTS_DIR_PATH = None
ARMJITSU_RECORD_DOS = None
#==================================END GLOBALS==============================================


def doesMasterTemplateforMessageExist(message_name, message_type = None) :
    
    messageMasterTemplateFilePath = getMessageMasterTemplateFilePath(message_name, message_type)

    #print "Master template file path for message '{}' is '{}'".format(message_name, messageMasterTemplateFilePath)
    
    return os.path.isfile(messageMasterTemplateFilePath) 
   

def getCurrentFolderFileCount(dir_path) :
    return len([name for name in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, name))])


def parseFuzzingFrameworkManagerArgs() :


    #----------------------BEGIN PARSING ARGUMENTS----------------------------      
    parser = argparse.ArgumentParser(description='Generate  fuzzed ASN XER messages.')

    # Argument: 'fuzz_type'
    parser.add_argument("-fuzz_type", help="UMTS or LTE")

    #Argument:'message_type'
    parser.add_argument("-message_type", help="use -displayMessages for a list of messages")

    #Argument:'message names'
    parser.add_argument('-message_names', nargs='*',
                         help='names of  messages to fuzz (e.g. "rrcConnectionSetupComplete"', 
                         default=DEFAULT_MESSAGE_LIST)

    #Argument: 'xsdpath'
    parser.add_argument("-xsdpath", help="path of Marben XSD file")

    #Argument: 'template_out_dir'
    parser.add_argument("-master_template_dir_path", help="directory path of master templates")

    #Argument: 'displayMessages'
    parser.add_argument("-displayMessages", help="displays the names of all the fuzzable UMTS or LTE messages",  action="store_true")

    #Argument: 'maxNumFuzzableMessages'
    parser.add_argument("-maxNumFuzzableMessages", help="set max number of fuzzable messages", default =DEFAULT_MAX_NUMBER_FUZZED_MESSAGES)

    #Argument: 'populateTemplateWithXER'
    parser.add_argument("-populateTemplateWithXER", help="Populates the template with specified XER message file path")

    #Argument: 'fuzzWithPopulatedTemplate'
    parser.add_argument("-fuzzWithPopulatedTemplate", help="fuzz with the  specified populated template file path")

    #Argument: 'numStage1FuzzedMessages'
    parser.add_argument("-numStage1FuzzedMessages", help="Number of stage1 complex messages to fuzz, increases variety of messages, but can take a while for large messages", default =DEFAULT_NUMBER_STAGE_1_FUZZED_MESSAGES)

    #Argument: 'fuzzWithArmulator'
    parser.add_argument("-fuzzWithArmulator", help="fuzz using ARMulator", action="store_true")

    #Argument: 'maxArmulatorInstances'
    parser.add_argument("-maxArmulatorInstances", help="max number of ARMulator instances to run", default=DEFAULT_ARMULATOR_INSTANCES)

    #Argument: 'armulatorTimeout'
    parser.add_argument("-armulatorTimeout", help="max time in milliseconds an instance should run for before saving the test case as a DoS", default=DEFAULT_ARMULATOR_TIMEOUT)

    #Argument: 'armulatorUseSnapshot'
    parser.add_argument("-armulatorUseSnapshot", help="will cause ARMulator to use the \"snapshot\" file in its directory", action="store_true")

    #Argument: 'fuzzWithArmjitsu'
    parser.add_argument("-fuzzWithArmjitsu", help="fuzz using ARMjitsu", action="store_true")

    # Argument: 'maxArmjitsuInstances'
    parser.add_argument("-maxArmjitsuInstances", help="max number of ARMjitsu instances to run", default=DEFAULT_ARMJITSU_INSTANCES)

    #Argument: 'armjitsuTimeout'
    parser.add_argument("-armjitsuTimeout", help="max time in milliseconds an instance should run for before saving the test case as a DoS", default=DEFAULT_ARMJITSU_TIMEOUT)

    #Argument: 'armjitsuIni'
    parser.add_argument("-armjitsuIni", help="ARMulator snapshot ini file to use with ARMjitsu")

    #Argument: armjitsuRecordDos
    parser.add_argument("-armjitsuRecordDos", help="Save test cases that might have caused a DoS", action="store_true")

    args = parser.parse_args()

    #----------------------END PARSING ARGUMENTS----------------------------   

    return args


def generateStage1FuzzedMessageOutName(message_name) :
    time_as_string= datetime.utcnow().strftime('%Y-%m-%d_%H-%M-%S-%f')[:-3]

    if FUZZ_WITH_ARMULATOR or FUZZ_WITH_ARMJITSU:
        return message_name + "_" +time_as_string+ XML_EXT
    else:
        return STAGE_1_FUZZING_OUT_DIR_PATH + message_name + "_" + time_as_string + XML_EXT


def generateStage2FuzzedMessageOutName(message_name) :
    time_as_string= datetime.utcnow().strftime('%Y-%m-%d_%H-%M-%S-%f')[:-3]

    if FUZZ_WITH_ARMULATOR or FUZZ_WITH_ARMJITSU:
        return message_name + "_" + time_as_string + XML_EXT
    else:
        return STAGE_2_FUZZING_OUT_DIR_PATH + message_name + "_" + time_as_string + XML_EXT


def generatePopulatedTemplateFileName(message_name) :
    time_as_string= datetime.utcnow().strftime('%Y-%m-%d_%H-%M-%S-%f')[:-3]
    return POPULATED_TEMPLATES_DIR_PATH + message_name + "populatedTemplate"+ "_" +time_as_string+ XML_EXT


def getMessageMasterTemplateFilePath(message_name, message_type = None) :
    global MASTER_TEMPLATE_DIR_PATH
    
    if message_type is not None:
        messageMasterTemplateFilePath = MASTER_TEMPLATE_DIR_PATH  + message_name + '_' + message_type + '_' + MESSAGE_TEMPLATE_SUFFIX + XML_EXT
    else:
        messageMasterTemplateFilePath = MASTER_TEMPLATE_DIR_PATH  + message_name + MESSAGE_TEMPLATE_SUFFIX + XML_EXT
    return messageMasterTemplateFilePath


def createMasterTemplateForMessage(message_name, message_type = None) :
    global XSD_FILE_PATH

    message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, message_type)
    generateMessageTemplate(message_name, message_type, message_master_template_file_path,XSD_FILE_PATH)


def startFuzzingThreads(messages2Fuzz):
    random.seed(datetime.now())

    if POPULATED_TEMPLATE_FILE_PATH is None:
        if messages2Fuzz is None:
            messages2Fuzz = MESSAGES2FUZZ

        for message_name in messages2Fuzz:
            # Create a master template if one does not exist
            if not doesMasterTemplateforMessageExist(message_name, MESSAGE_TYPE):
                print "Master template for message '{}' does not exist..Creating\n".format(message_name)
                createMasterTemplateForMessage(message_name, MESSAGE_TYPE)

    if FUZZ_WITH_ARMULATOR:
        print "Starting ARMulator threads..."

        for job_num in xrange(MAX_ARMULATOR_INSTANCES):
            p = Process(target=armulatorThread, args=(job_num, messages2Fuzz,))
            p.start()

            print "Started %d..." % job_num
    elif FUZZ_WITH_ARMJITSU:
        print "Starting ARMjitsu threads..."

        for job_num in xrange(MAX_ARMJITSU_INSTANCES):
            p = Process(target=armjitsuThread, args=(job_num, messages2Fuzz,))
            p.start()

            print "Started %d..." % job_num
    else:
        print "Should not be here!"


def fuzzingFrameworkManager(messages2Fuzz= None) :    
    global DISPLAY_FUZZABLE_MESSAGES
    global XER_FILE_PATH_FOR_POPULATING
    global POPULATED_TEMPLATE_FILE_PATH

    initialize()

    #If option is specified to display fuzzable UMTS or LTE messages, perform operation and then return
    if DISPLAY_FUZZABLE_MESSAGES == True:
        displayFuzzableMessages(XSD_FILE_PATH, FUZZ_TYPE)
        
    #Create a populated template using the specifed xer file
    elif XER_FILE_PATH_FOR_POPULATING != None :
        populateTemplateWithXER(XER_FILE_PATH_FOR_POPULATING)
       
    elif POPULATED_TEMPLATE_FILE_PATH !=None :
        if FUZZ_WITH_ARMULATOR or FUZZ_WITH_ARMJITSU:
            startFuzzingThreads(messages2Fuzz)
        else:
            fuzzPopulatedTemplate()
        
    else :
        if FUZZ_WITH_ARMULATOR or FUZZ_WITH_ARMJITSU:
            startFuzzingThreads(messages2Fuzz)
        else:
            fuzzMasterTemplates(messages2Fuzz)
 

def initialize() :
    global MESSAGES2FUZZ, MASTER_TEMPLATE_DIR_PATH, XSD_FILE_PATH, DISPLAY_FUZZABLE_MESSAGES, MAX_NUMBER_FUZZED_MESSAGES, NUMBER_STAGE_1_FUZZED_MESSAGES, MESSAGE_TYPE
    global XER_FILE_PATH_FOR_POPULATING, POPULATED_TEMPLATE_FILE_PATH
    global FUZZ_TYPE, RRCCONVERT
    global FUZZ_WITH_ARMULATOR, MAX_ARMULATOR_INSTANCES, ARMULATOR_JOB_RESULTS_DIR_PATH, ARMULATOR_TIMEOUT, ARMULATOR_USE_SNAPSHOT
    global FUZZ_WITH_ARMJITSU, ARMJITSU_TIMEOUT, MAX_ARMJITSU_INSTANCES, ARMJITSU_INI, ARMJITSU_JOB_RESULTS_DIR_PATH, ARMJITSU_INI_VALUES, ARMJITSU_RECORD_DOS

    #Parse command line arguments
    args = parseFuzzingFrameworkManagerArgs()

    #Initialize Globals
    MESSAGES2FUZZ = args.message_names
    MESSAGE_TYPE = args.message_type
    MASTER_TEMPLATE_DIR_PATH = args.master_template_dir_path
    XSD_FILE_PATH = args.xsdpath
    DISPLAY_FUZZABLE_MESSAGES = args.displayMessages
    MAX_NUMBER_FUZZED_MESSAGES = int(args.maxNumFuzzableMessages)
    XER_FILE_PATH_FOR_POPULATING = args.populateTemplateWithXER
    POPULATED_TEMPLATE_FILE_PATH = args.fuzzWithPopulatedTemplate
    NUMBER_STAGE_1_FUZZED_MESSAGES = int(args.numStage1FuzzedMessages)
    FUZZ_TYPE = args.fuzz_type
    FUZZ_WITH_ARMULATOR = args.fuzzWithArmulator
    MAX_ARMULATOR_INSTANCES = int(args.maxArmulatorInstances)
    ARMULATOR_TIMEOUT = int(args.armulatorTimeout)
    ARMULATOR_USE_SNAPSHOT = args.armulatorUseSnapshot
    FUZZ_WITH_ARMJITSU = args.fuzzWithArmjitsu
    ARMJITSU_TIMEOUT = int(args.armjitsuTimeout)
    MAX_ARMJITSU_INSTANCES = int(args.maxArmjitsuInstances)
    ARMJITSU_INI = args.armjitsuIni
    ARMJITSU_RECORD_DOS = args.armjitsuRecordDos

    #Must be UMTS or LTE
    if FUZZ_TYPE is None:
        print "Fuzz type not specified, the supported types are ", SUPPORTED_FUZZ_TYPES[0:]
        sys.exit()
    elif FUZZ_TYPE not in SUPPORTED_FUZZ_TYPES:
        print "Invalid fuzz type, the supported types are ", SUPPORTED_FUZZ_TYPES[0:]
        sys.exit()

    if FUZZ_TYPE == "UMTS":
        RRCCONVERT = importlib.import_module("rrcConvert.UMTS.rrcConvert")
    elif FUZZ_TYPE == "LTE":
        RRCCONVERT = importlib.import_module("rrcConvert.LTE.rrcConvert")

    if MASTER_TEMPLATE_DIR_PATH is None:
        print "Master template path not specified, using default path for {}".format(FUZZ_TYPE)
        if FUZZ_TYPE == "UMTS":
            MASTER_TEMPLATE_DIR_PATH = DEFAULT_UMTS_MASTER_TEMPLATES_PATH
        elif FUZZ_TYPE == "LTE":
            MASTER_TEMPLATE_DIR_PATH = DEFAULT_LTE_MASTER_TEMPLATES_PATH

    if XSD_FILE_PATH is None:
        print "XSD file path not specified, using default path for {}".format(FUZZ_TYPE)
        if FUZZ_TYPE == "UMTS":
            XSD_FILE_PATH = DEFAULT_UMTS_XSD_FILE_PATH
        elif FUZZ_TYPE == "LTE":
            XSD_FILE_PATH = DEFAULT_LTE_XSD_FILE_PATH

    # Make sure message type is valid
    if MESSAGE_TYPE is not None:
        if (FUZZ_TYPE == "UMTS") and (MESSAGE_TYPE not in SUPPORTED_UMTS_MESSAGE_TYPES):
            print "Invalid UMTS message type, the supported types are ", SUPPORTED_UMTS_MESSAGE_TYPES[0:]
            sys.exit()
        elif (FUZZ_TYPE == "LTE") and (MESSAGE_TYPE not in SUPPORTED_UMTS_MESSAGE_TYPES):
            print "Invalid LTE message type, the supported types are ", SUPPORTED_LTE_MESSAGE_TYPES[0:]
            sys.exit()

    if (MESSAGE_TYPE is None) and (DISPLAY_FUZZABLE_MESSAGES is False):
        print "Message type not specified, using default type of '{}, message type should usually be specified'".format(DEFAULT_MESSAGE_TYPE)
        MESSAGE_TYPE = DEFAULT_MESSAGE_TYPE

    if FUZZ_WITH_ARMULATOR:
        if MAX_ARMULATOR_INSTANCES <= 0:
            print "Invalid max armulator instances value, should be greater than 0"
            sys.exit()
        elif ARMULATOR_TIMEOUT <= 0:
            print "Invalid armulator timeout value, should be greater than 0"
            sys.exit()

    if FUZZ_WITH_ARMJITSU:
        if MAX_ARMJITSU_INSTANCES <= 0:
            print "Invalid max armjitsu instances value, should be greater than 0"
            sys.exit()
        elif ARMJITSU_TIMEOUT <= 0:
            print "Invalid armjitsu timeout value, should be greater than 0"
            sys.exit()
        elif not os.path.exists(ARMJITSU_INI):
            print "Unable to find armjitsu ini file"
            sys.exit()

        ARMJITSU_INI_VALUES = parseArmjitsuIni(ARMJITSU_INI)

    if not os.path.exists(FUZZING_FRAMEWORK_ROOT_PATH):
        print "Creating root fuzzing  directory '{}' ".format(FUZZING_FRAMEWORK_ROOT_PATH)
        os.makedirs(FUZZING_FRAMEWORK_ROOT_PATH)

    if FUZZ_WITH_ARMULATOR:
        if os.path.exists(ARMULATOR_FUZZING_DIR_PATH):
            shutil.rmtree(ARMULATOR_FUZZING_DIR_PATH)

        # Create subdirectories and copy over ARMulator files
        print "Creating directory '{}' to store ARMulator jobs".format(ARMULATOR_FUZZING_DIR_PATH)
        for i in xrange(MAX_ARMULATOR_INSTANCES):
            dst = ARMULATOR_FUZZING_DIR_PATH + str(i)

            if not os.path.exists(dst):
                os.makedirs(dst)

            for item in os.listdir(ARMULATOR_DIR_PATH):
                s = os.path.join(ARMULATOR_DIR_PATH, item)
                d = os.path.join(dst, item)

                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    if not os.path.exists(d) or os.stat(s).st_mtime - os.stat(d).st_mtime > 1:
                        shutil.copy2(s, d)

        if not os.path.exists(ARMULATOR_RESULTS_DIR_PATH):
            os.makedirs(ARMULATOR_RESULTS_DIR_PATH)

        ARMULATOR_JOB_RESULTS_DIR_PATH = ARMULATOR_RESULTS_DIR_PATH + str(datetime.now()).replace(" ", "_") + "/"
        os.makedirs(ARMULATOR_JOB_RESULTS_DIR_PATH + "dos")
        os.makedirs(ARMULATOR_JOB_RESULTS_DIR_PATH + "crash")

    elif FUZZ_WITH_ARMJITSU:
        if os.path.exists(ARMJITSU_FUZZING_DIR_PATH):
            shutil.rmtree(ARMJITSU_FUZZING_DIR_PATH)

        # Create subdirectories
        print "Creating directory '{}' to store ARMjitsu jobs"
        for i in xrange(MAX_ARMJITSU_INSTANCES):
            dst = ARMJITSU_FUZZING_DIR_PATH + str(i)

            if not os.path.exists(dst):
                os.makedirs(dst)

        if not os.path.exists(ARMJITSU_RESULTS_DIR_PATH):
            os.makedirs(ARMJITSU_RESULTS_DIR_PATH)

        ARMJITSU_JOB_RESULTS_DIR_PATH = ARMJITSU_RESULTS_DIR_PATH + str(datetime.now()).replace(" ", "_") + "/"

        if ARMJITSU_RECORD_DOS:
            os.makedirs(ARMJITSU_JOB_RESULTS_DIR_PATH + "dos")

        os.makedirs(ARMJITSU_JOB_RESULTS_DIR_PATH + "crash")

    else:
        #Create the following directories to store intermediate results
        if not os.path.exists(STAGE_1_FUZZING_OUT_DIR_PATH):
            print "Creating directory '{}' to store stage 1 fuzzing results".format(STAGE_1_FUZZING_OUT_DIR_PATH)
            os.makedirs(STAGE_1_FUZZING_OUT_DIR_PATH)

        if not os.path.exists(STAGE_2_FUZZING_OUT_DIR_PATH):
            print "Creating directory '{}' to store stage 2 fuzzing results".format(STAGE_2_FUZZING_OUT_DIR_PATH)
            os.makedirs(STAGE_2_FUZZING_OUT_DIR_PATH)

        if not os.path.exists(STAGE_3_FUZZING_OUT_DIR_PATH):
            print "Creating directory '{}' to store stage 3 fuzzing results".format(STAGE_2_FUZZING_OUT_DIR_PATH)
            os.makedirs(STAGE_3_FUZZING_OUT_DIR_PATH)

        if not os.path.exists(FUZZED_UPER_MESSAGES_DIR_PATH):
            print "Creating directory '{}' to store UPER messages".format(FUZZED_UPER_MESSAGES_DIR_PATH)
            os.makedirs(FUZZED_UPER_MESSAGES_DIR_PATH)

        if not os.path.exists(POPULATED_TEMPLATES_DIR_PATH):
            print "Creating directory '{}' to store populated templates".format(POPULATED_TEMPLATES_DIR_PATH)
            os.makedirs(POPULATED_TEMPLATES_DIR_PATH)

        #Empty out contents of hidden stage directories
        filelist = [ f for f in os.listdir(STAGE_1_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
        for f in filelist:
            file_path = os.path.join(STAGE_1_FUZZING_OUT_DIR_PATH, f)
            os.remove(file_path)

        #Empty out contents of hidden stage directories
        filelist = [ f for f in os.listdir(STAGE_2_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
        for f in filelist:
            file_path = os.path.join(STAGE_2_FUZZING_OUT_DIR_PATH, f)
            os.remove(file_path)

        #Empty out contents of hidden stage directories
        filelist = [ f for f in os.listdir(STAGE_3_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
        for f in filelist:
            file_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
            os.remove(file_path)


def parseArmjitsuIni(ini):
    with open(ini, "r") as f:
        ini_data = f.read().splitlines()

    sections = {}
    current_section = ""

    for line in ini_data:
        if line.startswith("#") or line == "":
            # this is a comment line or an empty line, skip
            continue
        elif line.startswith("[") and line.endswith("]"):
            # line is a section
            current_section = line
            sections[current_section] = []
        else:
            # line is part of the section, add it
            sections[current_section].append(line)

    if "[VM]" not in sections:
        print "Unable to find '[VM]' section in ini file"
        return None

    fuzzer_section = None
    for line in sections["[VM]"]:
        if line.lower().startswith("fuzzer="):
            fuzzer_section = "[%s]" % line[7:]
            break

    if fuzzer_section is None:
        print "Unable to find FUZZER key in ini file"
        return None

    elif fuzzer_section not in sections:
        print "Unable to find '%s' section in ini file" % fuzzer_section
        return None

    write_length = None
    target_addrs = []
    target_length_addrs = []
    exit_addrs = []

    for line in sections[fuzzer_section]:
        if line.lower().startswith("writelength="):
            value = line[12:]

            if value.lower() == "true":
                write_length = True
            elif value.lower() == "false":
                write_length = False
            else:
                print "Invalid WRITELENGTH value in ini file"
                return None

        elif line.lower().startswith("targetaddrs="):
            value = line[12:]

            for v in value.split(" "):
                try:
                    converted_value = int(v, 16)
                except ValueError as e:
                    print "Invalid value in TARGETADDRS in ini file"
                    return None

                target_addrs.append(converted_value)

        elif line.lower().startswith("targetlengthaddrs="):
            value = line[18:]

            for v in value.split(" "):
                try:
                    converted_value = int(v, 16)
                except ValueError as e:
                    print "Invalid value in TARGETLENGTHADDRS in ini file"
                    return None

                target_length_addrs.append(converted_value)

        elif line.lower().startswith("exitaddrs="):
            value = line[10:]

            for v in value.split(" "):
                try:
                    converted_value = int(v, 16)
                except ValueError as e:
                    print "Invalid value in EXITADDRS in ini file"
                    return None

                exit_addrs.append(converted_value)

    if write_length is None:
        print "WRITELENGTH key not found in ini"
        return None
    elif len(target_addrs) == 0:
        print "No addresses supplied for TARGETADDRS key in ini file"
        return None
    elif write_length:
        if len(target_length_addrs) == 0:
            print "No addresses supplied for TARGETLENGTHADDRS key in ini file"
            return None
    elif len(exit_addrs) == 0:
        print "No addresses supplied for EXITADDRS key in ini file"
        return None

    return {"WRITELENGTH": write_length, "TARGETADDRS": target_addrs, "TARGETLENGTHADDRS": target_length_addrs, "EXITADDRS": exit_addrs}


def armulatorThread(job_num, messages2Fuzz):
    global POPULATED_TEMPLATE_FILE_PATH
    global MESSAGE_TYPE

    job_path = "%s%s/" % (ARMULATOR_FUZZING_DIR_PATH, job_num)
    #job_result_path = "%s%s/" % (ARMULATOR_JOB_RESULTS_DIR_PATH, str(job_num))
    #job_result_dos_path = "%s%s/" % (job_result_path, "dos")
    #job_result_crash_path = "%s%s/" % (job_result_path, "crash")

    job_result_dos_path = "%s%s/" % (ARMULATOR_JOB_RESULTS_DIR_PATH, "dos")
    job_result_crash_path = "%s%s/" % (ARMULATOR_JOB_RESULTS_DIR_PATH, "crash")

    fuzzed_complex_types_path = job_path + "stage1/"
    xer_message_path = job_path + "stage2/"
    fuzzed_uper_message_path = job_path + "fuzzed_uper_messages/"
    stage3_path = job_path + "stage3/"

    #os.mkdir(job_result_path)
    #os.mkdir(job_result_dos_path)
    #os.mkdir(job_result_crash_path)
    os.mkdir(fuzzed_complex_types_path)
    os.mkdir(xer_message_path)
    os.mkdir(fuzzed_uper_message_path)
    os.mkdir(stage3_path)

    stage_1_file_list = []
    stage_1_message_name_list = []

    crash_count = 0
    dos_count = 0

    job_fuzzed_file_path = job_path + "fuzzed.raw"
    job_log_file_path = job_path + "log.txt"
    job_ini_file_path = job_path + "test.ini"
    job_snapshot_file_path = job_path + "snapshot"

    # prepend path of job to any *FILE= values
    with open(job_ini_file_path, "r+") as f:
        ini_data = f.read()
        f.seek(0)
        f.write(ini_data.replace("FILE=", "FILE=" + job_path))
        f.truncate()

    if POPULATED_TEMPLATE_FILE_PATH is not None:
        stage_1_file_list = []
        stage_1_message_name_list = []
        message_name = getMessageNameofTemplate(POPULATED_TEMPLATE_FILE_PATH)
        # ---Step 1: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
        for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES):
            print "Generating fuzzed complex message #{} ('{}') ".format(str(i), message_name)
            message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
            fuzzed_complex_types_out_path = fuzzed_complex_types_path + generateStage1FuzzedMessageOutName(message_name)

            # call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
            p = Process(target=convertTemplate2FuzzedComplexTypesMessage,
                        args=(message_master_template_file_path, fuzzed_complex_types_out_path))
            p.start()
            p.join()
            stage_1_file_list.append(fuzzed_complex_types_out_path)
            stage_1_message_name_list.append(message_name)
    else:
        global MESSAGES2FUZZ
        global XSD_FILE_PATH

        # If None, then use the global
        if messages2Fuzz is None:
            messages2Fuzz = MESSAGES2FUZZ

        for message_name in messages2Fuzz:
            # ---Step 2: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
            for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES / len(messages2Fuzz)):
                print "Generating fuzzed complex message #{} ('{}') ".format(str(i), message_name)
                message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
                fuzzed_complex_types_out_path = fuzzed_complex_types_path + generateStage1FuzzedMessageOutName(message_name)

                # call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
                p = Process(target=convertTemplate2FuzzedComplexTypesMessage,
                            args=(message_master_template_file_path, fuzzed_complex_types_out_path))
                p.start()
                p.join()
                stage_1_file_list.append(fuzzed_complex_types_out_path)
                stage_1_message_name_list.append(message_name)

    number_of_stage_1_gen_files = len(stage_1_file_list)

    while True:
        currentFileCount = getCurrentFolderFileCount(fuzzed_uper_message_path)

        if currentFileCount < MAX_NUMBER_FUZZED_MESSAGES:
            # Pick a random stage 1 file to fuzz
            random_file_index = (random.randint(0, number_of_stage_1_gen_files - 1))

            # print "Random file index '{}'".format(random_file_index)
            stage1_file2fuzz = stage_1_file_list[random_file_index]
            xer_message_out_path = xer_message_path + generateStage2FuzzedMessageOutName(stage_1_message_name_list[random_file_index])

            # print "Xer message out path: '{}'".format(xer_message_out_path)
            primitiveElementFuzzer(stage1_file2fuzz, xer_message_out_path)

        if EXIT_THREADS:
            sys.exit()

        currentXERFileCount = getCurrentFolderFileCount(xer_message_path)
        if currentXERFileCount > 0:
            filelist = [f for f in os.listdir(xer_message_path) if f.endswith(XML_EXT)]
            for f in filelist:
                curr_xer_file_path = os.path.join(xer_message_path, f)
                new_xer_file_path = os.path.join(stage3_path, f)
                shutil.move(curr_xer_file_path, new_xer_file_path)

        else:
            print "No files to convert...sleeping for '{}' seconds".format(FOLDER_FULL_SLEEP_TIMEOUT)
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)

        # Process files waiting to be processed in Stage 3 holding directory
        numFuzzedUPERFiles = getCurrentFolderFileCount(fuzzed_uper_message_path)

        num_processed_files = 0
        if num_processed_files < MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles:
            filelist = [f for f in os.listdir(stage3_path) if f.endswith(XML_EXT)]

            for f in filelist:
                if num_processed_files < MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles:
                    xer_in_path = os.path.join(stage3_path, f)
                    new_file_name = os.path.splitext(f)[0] + HEX_EXT
                    uper_out_path = os.path.join(fuzzed_uper_message_path , new_file_name)

                    tree = ET.parse(xer_in_path)
                    root = tree.getroot()

                    p = Process(target=RRCCONVERT.Convert,
                                args=(xer_in_path, uper_out_path, root.tag, "ixer", "oper"))

                    p.start()
                    p.join()

                    # Delete the xer file after we've converted it to a uper
                    os.remove(xer_in_path)
                    num_processed_files = num_processed_files + 1

                    if not os.path.isfile(uper_out_path):
                        print "UPER file not found"
                        continue

                    uper_in = open(uper_out_path, "r")
                    uper_data = uper_in.read()
                    uper_in.close()

                    os.remove(uper_out_path)

                    try:
                        uper_data = unhexlify(uper_data)
                    except TypeError as e:
                        print "Job %d error unhexlifying data: %s" % (job_num, e.message)
                        continue

                    uper_out = open(job_path + "fuzzed.raw", "w")
                    uper_out.write(uper_data)
                    uper_out.close()

                    cmd = job_path + "ESEmulator.exe -c 1 -r 1 -v -i \"%s\" -s \"%s\"" % (job_ini_file_path, job_log_file_path)

                    if ARMULATOR_USE_SNAPSHOT:
                        cmd += " -l \"%s\"" % job_snapshot_file_path

                    p = subprocess.Popen(shlex.split(cmd))

                    delay = 0.001
                    timeout = ARMULATOR_TIMEOUT * delay

                    while p.poll() is None and timeout > 0:
                        time.sleep(delay)
                        timeout -= delay

                    if p.poll() is None:
                        p.kill()

                    dos_or_crash_found = False

                    if timeout <= 0:
                        print "Job %d timed out!" % job_num
                        # save a possible DoS
                        curr_dos_folder = "%s%d_%d/" % (job_result_dos_path, job_num, dos_count)
                        os.mkdir(curr_dos_folder)

                        shutil.move(job_fuzzed_file_path, curr_dos_folder + "fuzzed.raw")
                        shutil.move(job_log_file_path, curr_dos_folder + "log.txt")

                        dos_count += 1
                        dos_or_crash_found = True
                    elif os.path.isfile(job_log_file_path):
                        # check for an exception
                        f = open(job_log_file_path)
                        log_data = f.read()
                        f.close()

                        if "Exception" in log_data:
                            print "Job %d got an exception!" % job_num
                            # save exception
                            curr_crash_folder = "%s%d_%d/" % (job_result_crash_path, job_num, crash_count)
                            os.mkdir(curr_crash_folder)

                            shutil.move(job_fuzzed_file_path, curr_crash_folder + "fuzzed.raw")
                            shutil.move(job_log_file_path, curr_crash_folder + "log.txt")

                            crash_count += 1
                            dos_or_crash_found = True

                    if not dos_or_crash_found:
                        if os.path.isfile(job_fuzzed_file_path):
                            os.remove(job_fuzzed_file_path)

                        if os.path.isfile(job_log_file_path):
                            os.remove(job_log_file_path)


def armjitsuThread(job_num, messages2Fuzz):
    from armjitsu.armjitsu.armjitsu import FuzzingFramework
    global POPULATED_TEMPLATE_FILE_PATH
    global MESSAGE_TYPE

    # TODO: Add support for snapshot files
    armjitsu_job = FuzzingFramework(ARMJITSU_INI, True)

    job_path = "%s%s/" % (ARMJITSU_FUZZING_DIR_PATH, job_num)

    job_result_dos_path = "%s%s/" % (ARMJITSU_JOB_RESULTS_DIR_PATH, "dos")
    job_result_crash_path = "%s%s/" % (ARMJITSU_JOB_RESULTS_DIR_PATH, "crash")

    fuzzed_complex_types_path = job_path + "stage1/"
    xer_message_path = job_path + "stage2/"
    fuzzed_uper_message_path = job_path + "fuzzed_uper_messages/"
    stage3_path = job_path + "stage3/"

    os.mkdir(fuzzed_complex_types_path)
    os.mkdir(xer_message_path)
    os.mkdir(fuzzed_uper_message_path)
    os.mkdir(stage3_path)

    stage_1_file_list = []
    stage_1_message_name_list = []

    crash_count = 0
    dos_count = 0

    if POPULATED_TEMPLATE_FILE_PATH is not None:
        stage_1_file_list = []
        stage_1_message_name_list = []
        message_name = getMessageNameofTemplate(POPULATED_TEMPLATE_FILE_PATH)
        # ---Step 1: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
        for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES):
            print "Generating fuzzed complex message #{} ('{}') ".format(str(i), message_name)
            message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
            fuzzed_complex_types_out_path = fuzzed_complex_types_path + generateStage1FuzzedMessageOutName(message_name)

            # call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
            p = Process(target=convertTemplate2FuzzedComplexTypesMessage,
                        args=(message_master_template_file_path, fuzzed_complex_types_out_path))
            p.start()
            p.join()
            stage_1_file_list.append(fuzzed_complex_types_out_path)
            stage_1_message_name_list.append(message_name)
    else:
        global MESSAGES2FUZZ
        global XSD_FILE_PATH

        # If None, then use the global
        if messages2Fuzz is None:
            messages2Fuzz = MESSAGES2FUZZ

        for message_name in messages2Fuzz:
            # ---Step 2: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
            for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES / len(messages2Fuzz)):
                print "Generating fuzzed complex message #{} ('{}') ".format(str(i), message_name)
                message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
                fuzzed_complex_types_out_path = fuzzed_complex_types_path + generateStage1FuzzedMessageOutName(message_name)

                # call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
                p = Process(target=convertTemplate2FuzzedComplexTypesMessage,
                            args=(message_master_template_file_path, fuzzed_complex_types_out_path))
                p.start()
                p.join()
                stage_1_file_list.append(fuzzed_complex_types_out_path)
                stage_1_message_name_list.append(message_name)

    number_of_stage_1_gen_files = len(stage_1_file_list)

    while True:
        currentFileCount = getCurrentFolderFileCount(fuzzed_uper_message_path)

        if currentFileCount < MAX_NUMBER_FUZZED_MESSAGES:
            # Pick a random stage 1 file to fuzz
            random_file_index = (random.randint(0, number_of_stage_1_gen_files - 1))

            # print "Random file index '{}'".format(random_file_index)
            stage1_file2fuzz = stage_1_file_list[random_file_index]
            xer_message_out_path = xer_message_path + generateStage2FuzzedMessageOutName(stage_1_message_name_list[random_file_index])

            # print "Xer message out path: '{}'".format(xer_message_out_path)
            primitiveElementFuzzer(stage1_file2fuzz, xer_message_out_path)

        if EXIT_THREADS:
            sys.exit()

        currentXERFileCount = getCurrentFolderFileCount(xer_message_path)
        if currentXERFileCount > 0:
            filelist = [f for f in os.listdir(xer_message_path) if f.endswith(XML_EXT)]
            for f in filelist:
                curr_xer_file_path = os.path.join(xer_message_path, f)
                new_xer_file_path = os.path.join(stage3_path, f)
                shutil.move(curr_xer_file_path, new_xer_file_path)

        else:
            print "No files to convert...sleeping for '{}' seconds".format(FOLDER_FULL_SLEEP_TIMEOUT)
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)

        # Process files waiting to be processed in Stage 3 holding directory
        numFuzzedUPERFiles = getCurrentFolderFileCount(fuzzed_uper_message_path)

        num_processed_files = 0
        if num_processed_files < MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles:
            filelist = [f for f in os.listdir(stage3_path) if f.endswith(XML_EXT)]

            for f in filelist:
                if num_processed_files < MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles:
                    xer_in_path = os.path.join(stage3_path, f)
                    new_file_name = os.path.splitext(f)[0] + HEX_EXT
                    uper_out_path = os.path.join(fuzzed_uper_message_path , new_file_name)

                    tree = ET.parse(xer_in_path)
                    root = tree.getroot()

                    p = Process(target=RRCCONVERT.Convert,
                                args=(xer_in_path, uper_out_path, root.tag, "ixer", "oper"))

                    p.start()
                    p.join()

                    # Delete the xer file after we've converted it to a uper
                    os.remove(xer_in_path)
                    num_processed_files = num_processed_files + 1

                    if not os.path.isfile(uper_out_path):
                        print "UPER file not found"
                        continue

                    uper_in = open(uper_out_path, "r")
                    uper_data = uper_in.read()
                    uper_in.close()

                    os.remove(uper_out_path)

                    try:
                        uper_data = unhexlify(uper_data)
                    except TypeError as e:
                        print "Job %d error unhexlifying data: %s" % (job_num, e.message)
                        continue

                    # write data to addresses
                    for addr in ARMJITSU_INI_VALUES["TARGETADDRS"]:
                        if not armjitsu_job.write(addr, uper_data):
                            sys.exit()

                    if ARMJITSU_INI_VALUES["WRITELENGTH"]:
                        for addr in ARMJITSU_INI_VALUES["TARGETLENGTHADDRS"]:
                            # TODO: support different endianness
                            armjitsu_job.write(addr, struct.pack("<I", len(uper_data)))

                    for addr in ARMJITSU_INI_VALUES["EXITADDRS"]:
                        armjitsu_job.write_exit_bp(addr)

                    armjitsu_job.run(ARMJITSU_TIMEOUT)

                    if armjitsu_job.timed_out:
                        print "Job %d timed out!" % job_num

                        if ARMJITSU_RECORD_DOS:
                            # save a possible DoS
                            dos_out_path = "%s%d_%d.raw" % (job_result_dos_path, job_num, dos_count)

                            with open(dos_out_path, "w") as dos_out:
                                dos_out.write(uper_data)

                            dos_count += 1

                    elif armjitsu_job.got_exception:
                        print "Job %d got an exception!" % job_num
                        # save exception
                        crash_out_path = "%s%d_%d.raw" % (job_result_crash_path, job_num, crash_count)
                        crash_log_out_path = "%s%d_%d.txt" % (job_result_crash_path, job_num, crash_count)

                        with open(crash_out_path, "w") as crash_out:
                            crash_out.write(uper_data)

                        with open(crash_log_out_path, "w") as crash_log_out:
                            crash_log_out.write("%s\n\n%s" % (armjitsu_job.error_message, armjitsu_job.error_register_state))

                        crash_count += 1

                        armjitsu_job.reload()
                        gc.collect()


def fuzzPopulatedTemplate():
    global THREADS
    global EXIT_THREADS
    global MESSAGE_TYPE

    FNULL = open(os.devnull, 'w')

    stage_1_file_list = []
    stage_1_message_name_list = []
    message_name = getMessageNameofTemplate(POPULATED_TEMPLATE_FILE_PATH)
    #---Step 1: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
    for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES):
        print "Generating fuzzed complex message #{} ('{}') ".format(str(i),message_name)
        message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
        fuzzed_complex_types_out_path = generateStage1FuzzedMessageOutName(message_name)        
        #call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
        p = Process(target=convertTemplate2FuzzedComplexTypesMessage, args=(message_master_template_file_path,fuzzed_complex_types_out_path))
        p.start()
        p.join()
        stage_1_file_list.append(fuzzed_complex_types_out_path)
        stage_1_message_name_list.append(message_name)


    #---Step 2: Select a fuzzed complex message from stage 1 to fuzz---        
    number_of_stage_1_gen_files = len(stage_1_file_list)
    random.seed(datetime.now())

    curr_stage_2_folder_count = 0

    #Make sure we don't exceed the maximum number of fuzzed messages allowed in stage 2 folder  
    while  True :
        currentFileCount = getCurrentFolderFileCount(FUZZED_UPER_MESSAGES_DIR_PATH)
        if currentFileCount < MAX_NUMBER_FUZZED_MESSAGES:
            #Pick a random stage 1 file to fuzz
            random_file_index = (random.randint(0,number_of_stage_1_gen_files-1))

            #print "Random file index '{}'".format(random_file_index)
            stage1_file2fuzz = stage_1_file_list[random_file_index]
            xer_message_out_path = generateStage2FuzzedMessageOutName(stage_1_message_name_list[random_file_index])

            #print "Xer message out path: '{}'".format(xer_message_out_path)
            primitiveElementFuzzer(stage1_file2fuzz, xer_message_out_path)


        else :
            print "\nCurrent file count ('{}') for fuzzed messages equals or exceeds the MAX of '{}'".format(currentFileCount,
                                                                                   MAX_NUMBER_FUZZED_MESSAGES)
            print "Waiting for files to be removed..."
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)

        if EXIT_THREADS:
            sys.exit()
            

        currentXERFileCount = getCurrentFolderFileCount(STAGE_2_FUZZING_OUT_DIR_PATH)   
        if currentXERFileCount >0 :
            filelist = [ f for f in os.listdir(STAGE_2_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            for f in filelist:
                curr_xer_file_path = os.path.join(STAGE_2_FUZZING_OUT_DIR_PATH, f)
                new_xer_file_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                shutil.move(curr_xer_file_path, new_xer_file_path)

        else:
            print "No files to convert...sleeping for '{}' seconds".format(FOLDER_FULL_SLEEP_TIMEOUT )
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)
        

        #Process files waiting to be processed in Stage 3 holding directory
        numXERFiles2Process = getCurrentFolderFileCount(STAGE_3_FUZZING_OUT_DIR_PATH) 
        numFuzzedUPERFiles  = getCurrentFolderFileCount(FUZZED_UPER_MESSAGES_DIR_PATH) 

        num_processed_files = 0
        if num_processed_files  <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :
            print "\n**Generating UPER files...**\n"
            
            filelist = [ f for f in os.listdir(STAGE_3_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            #time.sleep(.5) #Delay needed in embedded devices, prevents a bug where we try to read the xml file before its contents are done being written
            for f in filelist:
                if num_processed_files <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :                 
                    xer_in_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                    new_file_name = os.path.splitext(f)[0]+HEX_EXT 
                    uper_out_path = os.path.join(FUZZED_UPER_MESSAGES_DIR_PATH, new_file_name)

                    tree = ET.parse(xer_in_path)
                    root = tree.getroot()
                    #rval = rrcConvert.Convert(xer_in_path, uper_out_path, root.tag, "ixer", "oper")
                    #if rval != 0 :
                    #    print "Error converting '{}' to UPER".format(f)

                    p = Process(target=RRCCONVERT.Convert, args=(xer_in_path, uper_out_path, root.tag, "ixer", "oper"))

                    p.start()
                    p.join()

                    #Delete the xer file after we've converted it to a uper
                    os.remove(xer_in_path) 
                    num_processed_files = num_processed_files + 1


def fuzzMasterTemplates(messages2Fuzz):
    global MESSAGES2FUZZ
    global THREADS
    global EXIT_THREADS
    global MESSAGE_TYPE
    global XSD_FILE_PATH

    FNULL = open(os.devnull, 'w') 

    #If None, then use the global
    if messages2Fuzz == None :
        messages2Fuzz = MESSAGES2FUZZ

    stage_1_file_list = []
    stage_1_message_name_list = []

    for message_name in messages2Fuzz :

        #---Step 1: Create a master template if one does not exist---
        if not doesMasterTemplateforMessageExist(message_name, MESSAGE_TYPE):
            print "Master template for message '{}' does not exist..Creating\n".format(message_name)
            createMasterTemplateForMessage(message_name, MESSAGE_TYPE)

        #---Step 2: Fuzz the complex types of message up to NUMBER_STAGE_1_FUZZED_MESSAGES times---
        for i in range(NUMBER_STAGE_1_FUZZED_MESSAGES/len(messages2Fuzz)):
            print "Generating fuzzed complex message #{} ('{}') ".format(str(i),message_name)
            message_master_template_file_path = getMessageMasterTemplateFilePath(message_name, MESSAGE_TYPE)
            fuzzed_complex_types_out_path = generateStage1FuzzedMessageOutName(message_name)        
            #call this in a separate process, that way when it is done all of the memory that it uses will be released, this is needed for larger messages
            p = Process(target=convertTemplate2FuzzedComplexTypesMessage, args=(message_master_template_file_path,fuzzed_complex_types_out_path))
            p.start()
            p.join()
            stage_1_file_list.append(fuzzed_complex_types_out_path)
            stage_1_message_name_list.append(message_name)
 

    #---Step 3: Select a fuzzed complex message from stage 1 to fuzz---        
    number_of_stage_1_gen_files = len(stage_1_file_list)
    random.seed(datetime.now())

    curr_stage_2_folder_count = 0

    #Make sure we don't exceed the maximum number of fuzzed messages allowed in stage 2 folder  
    while  True : 
       
        currentFileCount = getCurrentFolderFileCount(FUZZED_UPER_MESSAGES_DIR_PATH)           
        if currentFileCount < MAX_NUMBER_FUZZED_MESSAGES:
            #Pick a random stage 1 file to fuzz
            random_file_index = (random.randint(0,number_of_stage_1_gen_files-1))
            
            #print "Random file index '{}'".format(random_file_index)
            stage1_file2fuzz = stage_1_file_list[random_file_index]
            xer_message_out_path = generateStage2FuzzedMessageOutName(stage_1_message_name_list[random_file_index])
            
            #print "Xer message out path: '{}'".format(xer_message_out_path)
            primitiveElementFuzzer(stage1_file2fuzz, xer_message_out_path)


        else :
            print "\nCurrent file count ('{}') for fuzzed messages equals or exceeds the MAX of '{}'".format(currentFileCount,
                                                                                   MAX_NUMBER_FUZZED_MESSAGES)
            print "Waiting for files to be removed..."
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)

        if EXIT_THREADS:
            sys.exit()
            

        currentXERFileCount = getCurrentFolderFileCount(STAGE_2_FUZZING_OUT_DIR_PATH)   
        if currentXERFileCount >0 :
            filelist = [ f for f in os.listdir(STAGE_2_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            for f in filelist:
                curr_xer_file_path = os.path.join(STAGE_2_FUZZING_OUT_DIR_PATH, f)
                new_xer_file_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                shutil.move(curr_xer_file_path, new_xer_file_path)

        else:
            print "No files to convert...sleeping for '{}' seconds".format(FOLDER_FULL_SLEEP_TIMEOUT )
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)
        

        #Process files waiting to be processed in Stage 3 holding directory
        numXERFiles2Process = getCurrentFolderFileCount(STAGE_3_FUZZING_OUT_DIR_PATH) 
        numFuzzedUPERFiles  = getCurrentFolderFileCount(FUZZED_UPER_MESSAGES_DIR_PATH) 

        num_processed_files = 0
        if num_processed_files  <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :
            print "\n**Generating UPER files...**\n"
            
            filelist = [ f for f in os.listdir(STAGE_3_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            #time.sleep(.5) #Delay needed in embedded devices, prevents a bug where we try to read the xml file before its contents are done being written
            for f in filelist:
                if num_processed_files <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :                 
                    xer_in_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                    new_file_name = os.path.splitext(f)[0]+HEX_EXT 
                    uper_out_path = os.path.join(FUZZED_UPER_MESSAGES_DIR_PATH, new_file_name)

                    tree = ET.parse(xer_in_path)
                    root = tree.getroot()
                    #rval = rrcConvert.Convert(xer_in_path, uper_out_path, root.tag, "ixer", "oper")
                    #if rval != 0 :
                    #    print "Error converting '{}' to UPER".format(f)

                    p = Process(target=RRCCONVERT.Convert, args=(xer_in_path, uper_out_path, root.tag, "ixer", "oper"))

                    p.start()
                    p.join()

                    #Delete the xer file after we've converted it to a uper
                    os.remove(xer_in_path) 
                    num_processed_files = num_processed_files + 1


def populateTemplateWithXER(xer_message_in_path):    
    global POPULATED_TEMPLATES_DIR_PATH
    global MESSAGE_TYPE
    global XSD_FILE_PATH

    message_name = getNameOfXERMessage(xer_message_in_path)

    print "Populating '{}' template with XER {}".format(message_name,xer_message_in_path)

    # Use the user specified message type, if none was given get the default type for the given message name
    if MESSAGE_TYPE is None:
        message_type = DEFAULT_MESSAGE_TYPE
    else:
        message_type = MESSAGE_TYPE

    #Check if the master template exists for message. If not, create it
    if not doesMasterTemplateforMessageExist(message_name, message_type):
        createMasterTemplateForMessage(message_name, message_type)
   

    populated_template_out_path = generatePopulatedTemplateFileName(message_name)

    populateTemplateWithXERValues(xer_message_in_path, populated_template_out_path,MASTER_TEMPLATE_DIR_PATH, message_type )

    print "Populated template written to the following path: '{}'".format(populated_template_out_path)


def convertXERs2UPER() :
    global EXIT_THREADS


    FNULL = open(os.devnull, 'w')   
    
    while True:

        if EXIT_THREADS:
            sys.exit()
            

        currentXERFileCount = getCurrentFolderFileCount(STAGE_2_FUZZING_OUT_DIR_PATH)   
        if currentXERFileCount >0 :
            filelist = [ f for f in os.listdir(STAGE_2_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            for f in filelist:
                curr_xer_file_path = os.path.join(STAGE_2_FUZZING_OUT_DIR_PATH, f)
                new_xer_file_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                shutil.move(curr_xer_file_path, new_xer_file_path)

        else:
            print "No files to convert...sleeping for '{}' seconds".format(FOLDER_FULL_SLEEP_TIMEOUT )
            time.sleep(FOLDER_FULL_SLEEP_TIMEOUT)
        

        #Process files waiting to be processed in Stage 3 holding directory
        numXERFiles2Process = getCurrentFolderFileCount(STAGE_3_FUZZING_OUT_DIR_PATH) 
        numFuzzedUPERFiles  = getCurrentFolderFileCount(FUZZED_UPER_MESSAGES_DIR_PATH) 

        num_processed_files = 0
        if num_processed_files  <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :
            print "\n**Generating UPER files...**\n"
            
            filelist = [ f for f in os.listdir(STAGE_3_FUZZING_OUT_DIR_PATH) if f.endswith(XML_EXT) ]
            time.sleep(.5) #Delay needed in embedded devices, prevents a bug where we try to read the xml file before its contents are done being written
            for f in filelist:
                if num_processed_files <MAX_NUMBER_FUZZED_MESSAGES - numFuzzedUPERFiles :                 
                    xer_in_path = os.path.join(STAGE_3_FUZZING_OUT_DIR_PATH, f)
                    new_file_name = os.path.splitext(f)[0]+HEX_EXT 
                    uper_out_path = os.path.join(FUZZED_UPER_MESSAGES_DIR_PATH, new_file_name)

                    tree = ET.parse(xer_in_path)
                    root = tree.getroot()
                    #rval = rrcConvert.Convert(xer_in_path, uper_out_path, root.tag, "ixer", "oper")
                    #if rval != 0 :
                    #    print "Error converting '{}' to UPER".format(f)

                    p = Process(target=RRCCONVERT.Convert, args=(xer_in_path, uper_out_path, root.tag, "ixer", "oper"))

                    p.start()
                    p.join()


                    #Delete the xer file after we've converted it to a uper
                    os.remove(xer_in_path) 
                    num_processed_files = num_processed_files + 1


def main() :
    global EXIT_THREADS


    print "\n*********Fuzzing Framework Manager (Release v1.2)*********\n"

    try:
        fuzzingFrameworkManager()
        
    except KeyboardInterrupt:
        print "**Exiting Fuzzing Framework Manager.........**"
        EXIT_THREADS = True
        #Tells all threads to exit        
        for thread in THREADS :
            thread.join()


main()

