#===================================GLOBALS=================================================
global MESSAGE_TYPE
MESSAGE_TYPE = None  #Type of message (e.g. UL-DCCH vs DL-CCCH)

#==================================END GLOBALS==============================================
