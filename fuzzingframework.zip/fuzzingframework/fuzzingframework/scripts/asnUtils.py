import argparse
import getpass
import xml.etree.ElementTree as ET
from constants import *
import os



#==================================CONSTANTS================================================
USER_NAME = getpass.getuser()
ASN_MESSAGE_FILE_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/asn/25331_c30.asn".format(USER_NAME)
SUPPRESSED_ASN_MESSAGE_FILE_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/asn/25331_c30_NOCONTAINING.asn".format(USER_NAME)
HEX_STRING_IN_FILE_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/uper_messages/UE-CapabilityContainer-IEs_UPER_MESSAGE.hex".format(USER_NAME)
BINARY_STRING_IN_FILE_PATH = "C:/Users/{}/Documents/WPG/Roosevelt_IRAD/fuzzing/uper_messages/UE-CapabilityContainer-IEs_UPER_MESSAGE.bstring".format(USER_NAME)

FUZZING_FRAMEWORK_ROOT_PATH = "/fuzzingframework/"
DEFAULT_XSD_FILE_PATH = FUZZING_FRAMEWORK_ROOT_PATH+"/marben_xsds/UMTS.xsd"

ASN_KEYWORD_CONTAINING = "CONTAINING"


DEFAULT_ASN_DEFINITION_FILE_PATH = FUZZING_FRAMEWORK_ROOT_PATH +"/asn_defs/25331_c30.txt"
#==================================END CONSTANTS============================================



'''
    Description: Suppresses the 'CONTAINING' type by removing all references in the ASN mesage definitoin

'''

def hexString2BinaryString(hex_string_in_path, binary_string_out_path) :
    import binascii
    binary_string = ""
    
    hex_string = open(hex_string_in_path,'r').read()
    
    #binary_string =((binascii.hexlify(hex_string)))
    
    for i in range(len(hex_string)):    
        binary_string +=bin(int(hex_string[i],base=16))[2:].zfill(4)
    #    #binary_string += bin[int(hex_string[i],base=16)]
 
    f= open(binary_string_out_path,'w')
    f.write(binary_string)
    f.close()
    
def getMessageNameofTemplate(template_in_path) :
    tree = ET.parse(template_in_path)
    root = tree.getroot()

    fuzz_node = root.find(FUZZ_ELEMENT_NODE_TAG)

    return fuzz_node.attrib[FUZZ_ELEMENT_NODE_NAME_ATTRIB]


def getNameOfXERMessage(xer_in_file_path):
    tree = ET.parse(xer_in_file_path)
    root = tree.getroot()

    message_node = root.find(XER_MESSAGE_NODE_NAME)
    return message_node[0].tag
    pass

def suppressASNTypeContaining(asn_msg_def_file_path, suppressed_msg_def_file_path) :
    f = open(asn_msg_def_file_path,'r')
    
    asnDefinitionLines = f.readlines()
    supressedASNDefinitionLines = []
    
    for i in range(len(asnDefinitionLines)) :
        asnDefinitionLine = asnDefinitionLines[i]
        
        if ASN_KEYWORD_CONTAINING in asnDefinitionLine :
            #print "ASN KEYWORD Line--> {}".format(asnDefinitionLine)
            begin_index =asnDefinitionLine.find(ASN_KEYWORD_CONTAINING)
            end_index = asnDefinitionLine.find(")", begin_index)
            
            supressedASNDefinitionLine = asnDefinitionLine[0:begin_index-1]+ asnDefinitionLine[end_index+1:]
            #print "Suppressed ASN KEYWORD Line--> {}".format(supressedASNDefinitionLine)
            #print "Begin_index: {} End_index: {}\n".format(begin_index,end_index)
        
            supressedASNDefinitionLines.append(supressedASNDefinitionLine)
        
        else :
            supressedASNDefinitionLines.append(asnDefinitionLine)
            

    #Write suppressed messasge definition to specified file
    f = open(suppressed_msg_def_file_path,'w')
    f.writelines(supressedASNDefinitionLines)

def getXSDElementNodeName(xsdElementNode):
    if XSD_NAME_ATTRIBUTE in xsdElementNode.attrib.keys() :       
        return xsdElementNode.attrib[XSD_NAME_ATTRIBUTE]
    else :
        #XSD  node does not have a name        
        return ""

def getXSDComplexTypeNode(node_name,root):
    
    for complexTypeNode in root.iter(XSD_COMPLEX_TYPE_TAG):
            if XSD_NAME_ATTRIBUTE in complexTypeNode.attrib.keys():
                if node_name == complexTypeNode.attrib[XSD_NAME_ATTRIBUTE] :
                    return complexTypeNode
    return None

def getc1NodeFromControlChannelName(node_name, root):
    node = getXSDComplexTypeNode(node_name, root)

    if node is not None:
        for child in node.iter():
            if XSD_NAME_ATTRIBUTE in child.attrib:
                if child.attrib[XSD_NAME_ATTRIBUTE] == "c1":
                    return child[0].getchildren()

    return None

def displayFuzzableMessages(xsd_file_path, fuzz_type) :
    tree = ET.parse(xsd_file_path)
    root = tree.getroot()

    for control_channel_name in CONTROL_CHANNEL_MESSAGE_NAMES_LIST :            
        print "\n----Message Type: '{}'----".format(control_channel_name)
        xsdMessageTypeNodeName = control_channel_name+"Type_Type"

        control_channel_node = None
        if fuzz_type == "UMTS":
            control_channel_node = getXSDComplexTypeNode(xsdMessageTypeNodeName, root)
        elif fuzz_type == "LTE":
            control_channel_node = getc1NodeFromControlChannelName(xsdMessageTypeNodeName, root)

        if control_channel_node == None :
            print "Error finding control channel node '{}'".format(control_channel_name)
            continue
        

        '''
        NOTE: Message nodes are the grandchildren of the control channel node

            <xsd:complexType name="DL-DCCH-MessageType_Type">
                <xsd:choice>
                  <xsd:element name="activeSetUpdate" type="ActiveSetUpdate_Type"/>
                  <xsd:element name="assistanceDataDelivery" type="AssistanceDataDelivery_Type"/>
                  <xsd:element name="cellChangeOrderFromUTRAN" type="CellChangeOrderFromUTRAN_Type"/>
                  <xsd:element name="cellUpdateConfirm" type="CellUpdateConfirm_Type"/>
        '''
        for messageNode in control_channel_node[0] :
            message_node_name = getXSDElementNodeName(messageNode)
            print "\t'{}'".format(message_node_name)

       
def testHarness():
    print "====================BEGIN TEST======================\n"
        
        
    asn_msg_def_file_path = ASN_MESSAGE_FILE_PATH 
    suppressed_msg_def_file_path = SUPPRESSED_ASN_MESSAGE_FILE_PATH
    
    print "--- Suppressing ASN type 'CONTAINING' in definition file {}".format(asn_msg_def_file_path)
    suppressASNTypeContaining(asn_msg_def_file_path,suppressed_msg_def_file_path)

    hex_string_in_path = HEX_STRING_IN_FILE_PATH
    
    binary_string_out_path = BINARY_STRING_IN_FILE_PATH
    
    hexString2BinaryString(hex_string_in_path, binary_string_out_path)
    
    
    print "\n==================== END TEST======================="

def main():
    print "\n*********ASN UTILS (version 1.2)*********\n"

    #Parse ASN Utility arguments
    parser = argparse.ArgumentParser(description='ASN Utilities.')

    #Argument: 'stripContainingKeyword'
    parser.add_argument("-stripContainingKeyword", help="Strip the keyword 'Containing' from the specfied asn definition file")
    
    args = parser.parse_args()


    if args.stripContainingKeyword :
        asn_def_file_in_path = args.stripContainingKeyword
        print "Stripping keyword 'Containing' from the following asn file: '{}'".format(asn_def_file_in_path)

        asn_def_file_ext = os.path.splitext(asn_def_file_in_path )[1]
        asn_def_file_out_path =  os.path.splitext(asn_def_file_in_path )[0] + "_NoContaining" + asn_def_file_ext 

        suppressASNTypeContaining(asn_def_file_in_path,asn_def_file_out_path)
        
        print "Stripped definition file outputed to the following path: '{}'".format(asn_def_file_out_path)
    

    else:

        xer_message_file_path = "/fuzzingframework/xer_messages/rrcConnectionSetupMessage.xml"
        message_name = getNameOfXERMessage(xer_message_file_path)

        print "Name of message is {}".format(message_name)
        #testHarness()

  


if __name__ == "__main__" :    
    main()
