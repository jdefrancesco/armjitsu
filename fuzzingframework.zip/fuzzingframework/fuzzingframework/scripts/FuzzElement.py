import xml.etree.ElementTree as ET
import xml.dom.minidom
from constants import *

##
# @brief Representation of an asn definition element that includes the children elements and attributes of parent element
# @member name: Name of the asn defintion element
# @member type: ASN type (e.g. sequence,choice,integer, boolean, and enumerated)
# @member minOccurs: Minimum number of occurrences of the asn element
# @member maxOccurs: Maximum number of occurrences of the asn element
# @member minLength: Minimum length of asn element if primitive (e.g. bitstring)
# @member maxLength: Maximum length of asn element if primitive (e.g. bitstring
# @member minValue: Minimum value of asn element if primitive (e.g. integer)
# @member maxValue: Maximum value of asn element if primitive (e.g. integer)
# @member children: List of references to children fuzz-elements of parent element
class FuzzElement:
    def __init__(self, messageType=None) :
        self.name = None
        self.type = None
        self.minOccurs = None
        self.maxOccurs = None
        self.minLength = None
        self.maxLength = None
        self.minValue  = None
        self.maxValue  = None
        self.children = []
        self.messageType = messageType
        
    def prettyprint(self) :
        print "\n========Fuzz Element Struct========"
        print "Name: '{}'".format(self.name) 
        print "Type: '{}'".format(self.type)
        print "Min Occurs: '{}'".format(str(self.minOccurs))
        print "Max Occurs: '{}'".format(str(self.maxOccurs))     
        print "========END Fuzz Element Struct======\n"
       
    ##
    # @brief Recursively creates an xml tree representation of the fuzz element and children
    # @member fuzz_tree_root: xml parent node
    def createFuzzTree(self, fuzz_tree_root = None) :
        
        if(fuzz_tree_root == None):        
            fuzz_tree_root = ET.Element(FUZZ_TREE_ROOT_TAG)
            fuzz_tree_root.set(FUZZ_TREE_ROOT_MESSAGE_TYPE_ATTRIB,self.messageType)
                                
        #Create fuzz node and append to root       
        new_fuzz_node  = ET.SubElement(fuzz_tree_root,FUZZ_ELEMENT_NODE_NAME)
        
        
        #---------Populate node attributes with fuzz element information------------        
        #Type
        if self.type != None:
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_TYPE_ATTRIB, self.type)
       
        #Name
        if self.name == None:
            new_fuzz_node.set("", self.name)         
        elif self.name != None:          
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_NAME_ATTRIB, self.name)            
        
        #Occurrences
        if self.minOccurs != None:
            new_fuzz_node.set(XSD_ELEMENT_MIN_OCCUR_ATTRIBUTE, str(self.minOccurs))
        if self.maxOccurs != None:   
            new_fuzz_node.set(XSD_ELEMENT_MAX_OCCUR_ATTRIBUTE, str(self.maxOccurs))
        
        #Length
        if self.minLength != None :
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_MIN_LENGTH_ATTRIB, str(self.minLength))
            
        if self.maxLength !=None :
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_MAX_LENGTH_ATTRIB, str(self.maxLength))
         
        #Value 
        if self.minValue !=None :            
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_MIN_VALUE_ATTRIB, str(self.minValue))
            
        if self.maxValue !=None :            
            new_fuzz_node.set(FUZZ_ELEMENT_NODE_MAX_VALUE_ATTRIB, str(self.maxValue))                
        #--------------------------------End Populate--------------------------------  
        
        #Recursively add children to the tree
        if self.children !=None :            
            for child in self.children :               
                child.createFuzzTree(new_fuzz_node)
            
        return fuzz_tree_root
       
    ##
    # @brief Get the pretty print xml string
    # @return  xml string  
    def getPrettyPrintXMLString(self):
        fuzz_tree_root = self.createFuzzTree()
                
        fuzz_tree_string = ET.tostring(fuzz_tree_root)
                
        xmls = xml.dom.minidom.parseString(fuzz_tree_string)     
        pretty_fuzz_xml_tree_string = xmls.toprettyxml()
        
        return pretty_fuzz_xml_tree_string
    
    ##
    # @brief Get the pretty print xml string
    def prettyprintFuzzTree(self):
        print "{}".format(self.getPrettyPrintXMLString())
        
    ##
    # @brief Write xml tree to specified file
    # @param  xml_file_path path to write xml file to
    def writeTree2FileAsXML(self,xml_file_path) :    
        fuzz_tree_xml_string = self.getPrettyPrintXMLString()        
        f = open(xml_file_path, 'w')
        f.write(fuzz_tree_xml_string)
        f.close()
        print "Tree written as XML to path: {}".format(xml_file_path)
        
         
#===================================END CLASS DEFINITIONS==============================================
